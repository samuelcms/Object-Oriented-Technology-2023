package too.introducao.gui;

import java.util.StringTokenizer;
import static too.introducao.gui.EntradaESaida.*;

public class Tokenizacao 
{
	public static void main(String[] args) 
	{
		tokenizacao();
	}

	public static void tokenizacao() 
	{
		final String SEPARADORES = " .,:;?!";
		String str = lerString("Escreva uma frase", "Ler String");
		
		if(str != null)
		{
			StringTokenizer strTok = new StringTokenizer(str, SEPARADORES);
			String resultado = String.format("A string possui %d tokens. São eles: \n", strTok.countTokens());
			
			while (strTok.hasMoreElements()) 
			{
				String palavra = (String) strTok.nextElement();
				resultado += String.format("%s\n", palavra);
			}
			
			msgInfo(resultado, "Tokenização");
		}
		else
			msgAlerta("Operação cancelada", "Finalizando");
		
		System.exit(0);
	
	} // tokenizacao()
	
} // class Tokenizacao 