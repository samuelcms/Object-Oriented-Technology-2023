package too.introducao.gui;

import javax.swing.JOptionPane;

public class EntradaESaida 
{
	/**
	 * Exibe uma mensagem de informação em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida.
	 * @param titulo Título da janela.
	 */
	public static void msgInfo(String mensagem, String titulo) 
	{
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.INFORMATION_MESSAGE);		
	}

	/**
	 * Exibe uma mensagem de advertência em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida.
	 * @param titulo Título da janela.
	 */
	public static void msgAlerta(String mensagem, String titulo) 
	{
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.WARNING_MESSAGE);
	}
	
	/**
	 * Exibe uma mensagem de erro em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida.
	 * @param titulo Título da janela.
	 */
	public static void msgErro(String mensagem, String titulo) 
	{
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.ERROR_MESSAGE);
	}

	/**
	 * Lê uma string em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida na janela.
	 * @param titulo Título da janela.
	 * 
	 * @return Retorna a <code>String</code> lida na caixa de diálogo, ou null, quando a operação for cancelada.
	 */
	public static String lerString(String mensagem, String titulo) 
	{
		return JOptionPane.showInputDialog(null, mensagem, titulo, JOptionPane.QUESTION_MESSAGE);
	}

} // class EntradaESAida
