package too.introducao.gui;

import javax.swing.JOptionPane;

public class OlaMundo 
{
	public static void main(String[] args) 
	{
		olaMundo();
	}

	private static void showMessage(String message, String title, int icon)
	{
		JOptionPane.showMessageDialog(null, message, title, icon);
	}
	
	private static void olaMundo() 
	{
		String olaMundo = "Olá mundo!", saudacao = "Saudação", 
			   finalizar = "O programa será finalizado.", 
			   encerramento = "Encerramento";
		
		showMessage(olaMundo, saudacao, JOptionPane.INFORMATION_MESSAGE);
		showMessage(finalizar, encerramento, JOptionPane.WARNING_MESSAGE);
		
		// Finaliza a Máquina Virtual do Java (em outras palavras: Finaliza o programa).
		System.exit(0);
	}
} // class OlaMundo
