package too.introducao.gui;

import javax.swing.JOptionPane;

public class StringMutavelEImutavel 
{	
	public static void main(String[] args) 
	{
		stringMutavelEImutavel();
	}
	
	public static void stringMutavelEImutavel() 
	{
		stringImutavel();
		stringMutavel();
	}
	
	/**
	 * Reforça o conceito de que objetos da classe String são imutáveis.
	 * 
	 */
	public static void stringImutavel() 
	{
		String string = "Esta string não pode ser modificada.", string2 = new String("Esta string não pode ser modificada.");
						
		/*
		 * A atribuição abaixo não modifica o objeto String,ela altera a referência da variável 
		 * para o novo objeto anônimo do tipo String, que é a string vazia. 
		 */
		msgInfo("String: " + string, "String Imutável");
		string = "";
		msgInfo("String: " + string, "String Imutável");
		
		// Objetos anônimos do tipo String que são idênticos possuem a mesma referência.
		string = "Esta string não pode ser modificada.";
		
		if (string == "Esta string não pode ser modificada.") msgInfo("\n - Strings iguais.", "String Imutável");	
		else msgInfo("\n - Strings diferentes.", "String Imutável");
		
		if(string == string2) msgInfo("\n - Strings iguais.", "String Imutável");
		else msgInfo("\n - Strings diferentes.", "String Imutável");
		
		if(string.equals(string2)) msgInfo("\n - Strings iguais.", "String Imutável");
		else msgInfo("\n - Strings diferentes.", "String Imutável");
		
		if(string == string2.intern())msgInfo("\n - Strings iguais.", "String Imutável");
		else msgInfo("\n - Strings diferentes.", "String Imutável");
		
		if("oi".equals("OI"))msgInfo("\n - Strings iguais.", "String Imutável");
		else msgInfo("\n - Strings diferentes.", "String Imutável");

	}
	
	/**
	 * Apresenta a classe StringBuilder.
	 */
	
	public static void stringMutavel() 
	{
		// StringBuilder strBuilder;
		// StringBuffer strBuffer;
	}
	
	/**
	 * Exibe uma mensagem informativa em uma caixa de diálogo comum título.
	 * 
	 * @param mensagem Mensagem a ser exibidas
	 * @param titulo Título da janela
	 */
	public static void msgInfo(String mensagem, String titulo) 
	{
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.INFORMATION_MESSAGE);
	}
	
} // class StringMutavelEImutavel
