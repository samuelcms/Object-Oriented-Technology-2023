package too.introducao;

/*
 * Regras:
 * 
 * 	- OlaMundo:		Classe, Interface ou Enumeração
 * 	- olaMundo: 	Variável 
 * 	- olaMundo(): 	Método
 * 	- OLA_MUNDO: 	Constante
 * 
 */
public class OlaMundo 
{
	/**
	 * Inicia o programa Java.
	 * 
	 * @param args recebe os argumentos da linha de comando do sistema operacional.
	 */
	public static void main(String[] args) 
	{
		olaMundo();
	}

	private static void olaMundo() 
	{
		System.out.println("Olá mundo!");
		System.out.printf("Tchau mundo!");	
	}
} // class OlaMundo
