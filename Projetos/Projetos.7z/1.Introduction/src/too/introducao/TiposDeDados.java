package too.introducao;

public class TiposDeDados 
{
	public static void main(String[] args) 
	{
		tiposDeDados();
	}
	
	public static void tiposDeDados() 
	{
		tiposPrimitivos();
		tiposPorReferencia();
	}

	public static void tiposPrimitivos() 
	{	
		byte idade = Byte.MAX_VALUE; 					// Range de valores: -128 a 127. 
		int inteiro = Integer.MAX_VALUE;
		boolean verdadeiro = true;
		final float PI = 3.141592F;
		 
		System.out.println(" - Tipos Primitivos");
		
		System.out.print("\n\t - Boolean: " + verdadeiro);
		System.out.printf("\n\t - Inteiro: %,d", inteiro);
		System.out.printf("\n\t - Byte: %d", idade);
		System.out.printf("\n\t - Decimal: %.6f\n\n", PI);
	
	} // tiposPrimitivos
	
	public static void tiposPorReferencia()
	{
		String frase = "Hoje é dia 10.03.2023",
			   palavra = new String("Barbacena");
		
		Integer integer = Integer.valueOf(Integer.MAX_VALUE);
		final Double PI = Math.PI;
		
		Character charA = Character.valueOf('S');
		
		System.out.println(" - Tipos por Referência");
		System.out.printf("\n\t - Frase: %s", frase);
		System.out.printf("\n\t - Palavra: %s", palavra);
		System.out.printf("\n\t - Integer: %,d", integer);
		System.out.printf("\n\t - Double: %.15f", PI);
		System.out.printf("\n\t - Character: %c\n", charA.charValue());
		
		// O caractere 'u' refere-se ao código Unicode de um caractere. 
		System.out.printf("\n\t - Usando o método Character.getName(): ('\\u00A9') = %s\n", Character.getName('\u00A9'));
		System.out.printf("\n\t - O caractere armazenado em 'charA' é uma letra? %s \n\n", Character.isLetter(charA.charValue()));
	
	} // tiposPorReferencia()
	
} // class Tipos
