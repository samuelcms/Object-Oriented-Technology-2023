package too.arrays;

import static java.lang.String.format;

public class Matriz 
{
	public static void main(String[] args) 
	{
		matriz();
	}

	public static void matriz() 
	{ 
		int matriz3x3[][] = new int[3][3], 		// Cria uma matriz de números inteiros.
			matrizEscada[][] = new int[5][]; 	// Cria uma matriz de 5 linhas e com um número indefinido de colunas.

		// Define o número de colunas de cada linha da matriz matrizEscada.
		for(int linha = 0; linha < matrizEscada.length; linha++)
		{
			matrizEscada[linha] = new int[linha+1];
		}
		
		exibirMatriz(matriz3x3, "Matrix 3x3 - Antes da inicialização");
		inicializarMatriz(matriz3x3, 1, 1);
		exibirMatriz(matriz3x3, "Matrix 3x3 - Depois da inicialização");
		
		inicializarMatriz(matrizEscada, 1, 1);
		exibirMatriz(matrizEscada, "Matriz Escada");
		
	}
	
	// Inicializa uma matriz de números inteiros de acordo com o início e o passo.
	public static void inicializarMatriz(int matriz[][], int inicio, int passo)
	{
		for(int linha = 0, numero = inicio; linha < matriz.length; linha++)
		{
			for(int coluna = 0; coluna < matriz[linha].length; coluna++, numero += passo)
			matriz[linha][coluna] = numero;
		}
	}
	
	// Exibe no console os elementos da matriz no formato tabular.
	public static void exibirMatriz(int[][] matriz, String mensagem) 
	{
		print(format("\n - %s \n\n", mensagem));
		
		for(int[] linha : matriz)
		{
			for(int numero : linha)
				print(format(" %,02d", numero));
			
			print("\n");
		}
	}

	private static void print(String string)
	{
		System.out.print(string);
	}
		
} // class Matriz
