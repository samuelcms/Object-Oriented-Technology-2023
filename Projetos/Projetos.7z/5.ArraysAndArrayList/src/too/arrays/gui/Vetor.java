package too.arrays.gui;

import static too.arrays.gui.EntradaESaida.formatarSaida;
import static too.arrays.gui.EntradaESaida.msgInfo;

import java.util.Arrays;

public class Vetor 
{
	public static void main(String[] args) 
	{
		vetor();
	}

	public static void vetor()
	{
		int numerosPares[],						// Referência para um vetor do tipo int.
			numerosImpares[] = {1, 3, 5, 7, 9},	// Define e inicializa um vetor do tipo int.
			dez = 10;							// Variável do tipo int.	
		
		numerosPares = new int[dez];
		inicializarVetor(numerosPares, 0, 2);
		
		StringBuilder strBuilder = formatarSaida("Números pares: ", Arrays.toString(numerosPares), "\n", 
				                                 "Números ímpares: ", Arrays.toString(numerosImpares), "\n\n");
		
		msgInfo(strBuilder.toString(), "Array Unidimensional - Vetor");		
		System.exit(0);
				
	} // vetor()
	
	// Inicializa um vetor de números inteiros de acordo com o início e o passo.
	public static void inicializarVetor(int vetor[], int inicio, int passo)
	{
		for(int indice = 0, numero = inicio; indice < vetor.length; indice++, numero += passo)
			vetor[indice] = numero;
	}
	
	public static void exibirVetor() 
	{
		
	}

} // class Vetor
