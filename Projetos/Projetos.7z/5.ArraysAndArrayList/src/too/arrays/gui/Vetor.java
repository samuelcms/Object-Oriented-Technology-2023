package too.arrays.gui;

import static too.arrays.gui.EntradaESaida.*;

import java.util.Arrays;
import java.util.Scanner;

public class Vetor 
{
	public static void main(String[] args) 
	{
		vetor();
	}

	public static void vetor()
	{
		int numerosPares[],											// Referência para um vetor do tipo int.
			numerosImpares[] = {17, 9, 23, 1, 45, 7, 5, 81, 15 },	// Define e inicializa um vetor do tipo int.
			
			dez = 10;												// Variável do tipo int.
		
		char vogais[] = {'a', 'e', 'i', 'o', 'u' };
		
		numerosPares = new int[dez];
		int[] numerosInteiros = new int[dez / 2];
		long[] numerosInteirosLongos = new long[dez / 5];
		
		// Arrays em Java são inicializados com 0. 
		print(Arrays.toString(numerosPares),Arrays.toString(numerosInteiros), Arrays.toString(numerosInteirosLongos));
		
		inicializarVetor(numerosPares, 0, 2);
		inicializarVetor(numerosInteiros, 0, 1);
		inicializarVetor(numerosInteirosLongos, Integer.MAX_VALUE, -100000000);
		
		// Copia os caracteres do vetor vogais para o vetor letras criando um novo vetor de 26 caracteres.
		char[] letras = Arrays.copyOf(vogais, 26);
		
		/* Preencher o vetor letras com o caractere ponto (.). O preenchimento é feito da posição 5 até a última 
		 * posição do vetor.
		 */
		Arrays.fill(letras, 5, letras.length, ' ');
		System.out.printf("\nLetras: %s\n", Arrays.toString(letras));
		
		// Ordena de forma crescente o vetor de inteiros "numerosImpares".
		Arrays.sort(numerosImpares);

		StringBuilder strBuilder = formatarSaida("Números pares: ", Arrays.toString(numerosPares), "\n", 
				                                 "Números ímpares: ", formatarSaida(numerosImpares).toString(), "\n",
				                                 "Números inteiros: ", formatarSaida(numerosInteiros).toString(), "\n",
				                                 "Números inteiros longos: ", formatarSaida(numerosInteirosLongos).toString(),"\n",
				                                 "Letras: ", Arrays.toString(vogais));
		
		msgInfo(strBuilder.toString(), "Array Unidimensional - Vetor");	
		
		Scanner entrada = new Scanner(System.in);
		int numeroImpar, posicao;
		
		System.out.printf("\nNúmero ímpar: ");
		numeroImpar = entrada.nextInt();
		posicao = Arrays.binarySearch(numerosImpares, numeroImpar);
		
		if(posicao >= 0) System.out.println("Número correspondente.");
		else 			 System.err.println("Número não correspondente");
		
		entrada.close();
		
		System.exit(0);
				
	} // vetor()
	
	// Inicializa um vetor de números inteiros de acordo com o início e o passo.
	public static void inicializarVetor(int vetor[], int inicio, int passo)
	{
		for(int indice = 0, numero = inicio; indice < vetor.length; indice++, numero += passo)
			vetor[indice] = numero;
	}
	
	// Inicializa um vetor de números inteiros de acordo com o início e o passo.
	public static void inicializarVetor(long vetor[], long inicio, long passo)
	{
		var numero = inicio;	
		for(int indice = 0; indice < vetor.length; indice++, numero += passo)
			vetor[indice] = numero;
	}
	
	private static void print(String... strings)
	{
		for(String string : strings)
			System.out.println(string);
	}
	
} // class Vetor
