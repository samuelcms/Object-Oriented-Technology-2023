package too.arrays.gui;

import static javax.swing.JOptionPane.*;

public class EntradaESaida 
{
	// Variável de classe.
	static StringBuilder stringBuilder = new StringBuilder();
	
	public static final String NOVA_LINHA = "\n";
	public static final String LINHA_VAZIA = "\n\n";
	
	/**
	 * Exibe uma mensagem de informação em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida.
	 * @param titulo Título da janela.
	 * 
	 * @see javax.swing.JOptionPane
	 */
	public static void msgInfo(String mensagem, String titulo) 
	{
		showMessageDialog(null, mensagem, titulo, INFORMATION_MESSAGE);		
	}

	/**
	 * Exibe uma mensagem de advertência em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida.
	 * @param titulo Título da janela.
	 * 
 	 * @see javax.swing.JOptionPane
	 */
	public static void msgAlerta(String mensagem, String titulo) 
	{
		showMessageDialog(null, mensagem, titulo, WARNING_MESSAGE);
	}
	
	/**
	 * Exibe uma mensagem de erro em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida.
	 * @param titulo Título da janela.
	 * 
 	 * @see javax.swing.JOptionPane
	 */
	public static void msgErro(String mensagem, String titulo) 
	{
		showMessageDialog(null, mensagem, titulo, ERROR_MESSAGE);
	}

	/**
	 * Lê uma string em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida na janela.
	 * @param titulo Título da janela.
	 * 
	 * @return Retorna a <code>String</code> lida na caixa de diálogo, ou null, quando a operação for cancelada.
 	 *
 	 * @see javax.swing.JOptionPane
	 */
	public static String lerString(String mensagem, String titulo) 
	{
		return showInputDialog(null, mensagem, titulo, QUESTION_MESSAGE);
	}
	
	/**
	 * Lê um número inteiro em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida na janela.
	 * @param titulo Título da janela.
	 * 
	 * @return Retorna o número lido na caixa de diálogo, ou null, quando a operação for cancelada.
	 * 
	 * @see javax.swing.JOptionPane
	 */
	public static Integer lerNumeroInteiro(String mensagem, String titulo) 
	{
		String str = lerString(mensagem, titulo);
		return ((str != null)) ? Integer.parseInt(str) : null;
	}
	
	/**
	 * Lê um número real em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida na janela.
	 * @param titulo Título da janela.
	 * 
	 * @return Retorna o número lido na caixa de diálogo, ou null, quando a operação for cancelada.
	 * 
	 * @see javax.swing.JOptionPane
	 */
	public static Double lerNumeroReal(String mensagem, String titulo) 
	{
		String str = lerString(mensagem, titulo);
		return ((str != null)) ? Double.parseDouble(str) : null;
	}
	
	/**
	 * Cria e retorna um objeto StringBuilder formatado com os argumentos passados via parâmetro.
	 * A formatação é definida pela sequência que os argumentos são adicionados.
	 * 
	 * @return A string formatada.
	 */
	public static StringBuilder formatarSaida(String string)
	{	
		return stringBuilder.append(string);
	}
	
	/**
	 * Cria e retorna um objeto StringBuilder formatado com os argumentos string passados via 
	 * parâmetro. A formatação é definida pela sequência que os argumentos são adicionados.
	 * 
	 * @return A string formatada.
	 */
	public static StringBuilder formatarSaida(String... strings)
	{	
		StringBuilder stringBuilder = new StringBuilder();
		
		for (String string : strings) 
			stringBuilder.append(string);
		
		return stringBuilder;
	}
	
	/**
	 * Cria e retorna um objeto StringBuilder formatado com os argumentos int passados via 
	 * parâmetro. A formatação é definida pela sequência que os argumentos são adicionados.
	 * 
	 * @return A string formatada.
	 */
	public static StringBuilder formatarSaida(int... numeros)
	{	
		StringBuilder strBuilder = new StringBuilder();
		
		for (var numero : numeros) 
			strBuilder.append(numero);
			
		return strBuilder;
	}
	
} // class EntradaESaida