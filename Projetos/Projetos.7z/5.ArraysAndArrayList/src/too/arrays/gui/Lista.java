package too.arrays.gui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static too.arrays.gui.EntradaESaida.*;

public class Lista 
{
	public static void main(String[] args) 
	{
		lista();
		
		System.exit(0);
	}

	private static void lista() 
	{
		// Cria uma lista para armazenar objetos Integer e String.
		List<Integer>numerosList = new ArrayList<>();
		List<String> stringList = new ArrayList<>();
		String saida;
		
		inicializarLista(numerosList, 15, 25, 5, 10, 20);
		inicializarLista(stringList, "Desterro do Melo", "Camanducaia", "Esmeraldas", "Barbacena", "Alfenas");
		
		saida = formatarSaida("Listas Desordenadas", LINHA_VAZIA,
							  "Números: ", numerosList.toString(), NOVA_LINHA,
						  	  "Palavras: ", stringList.toString(), LINHA_VAZIA).toString();
	
		Collections.sort(numerosList);
		Collections.sort(stringList);
		
		saida = formatarSaida(saida, "Listas Ordenadas", LINHA_VAZIA,
				  			  "Números: ", numerosList.toString(), NOVA_LINHA,
				  			  "Palavras: ", stringList.toString(), LINHA_VAZIA).toString();
		
		// Obtendo uma sublista da lista de números.
		saida = formatarSaida(saida, "Sublista de números: ", numerosList.subList(0, 3).toString(), LINHA_VAZIA).toString();
		
		// Obtém um vetor com os elementos da lista.
		saida = formatarSaida(saida, "Vetor de strings: ", Arrays.toString(stringList.toArray()), LINHA_VAZIA).toString();
		
		msgInfo(saida, "Exemplo - ArrayList");
		
		// Pesquisa um elemento na lista.
		System.out.println(String.format("A cidade Barbacena %sestá na lista.\n" , stringList.contains("Barbacena") ? "" : "não "));
				
		// Apaga todos os elementos da lista.
		numerosList.clear();
		stringList.clear();
		
		System.err.println("numerosList: " + numerosList);
		System.err.println("stringList:  " + stringList);
		
	}

	public static void inicializarLista(List<Integer> numerosList, int... numeros) 
	{
		for(int numero : numeros)
			numerosList.add(numero);
	}
	
	public static void inicializarLista(List<String> stringList, String... strings) 
	{
		for(String string : strings)
			stringList.add(string);
	}
	
} // class Lista
