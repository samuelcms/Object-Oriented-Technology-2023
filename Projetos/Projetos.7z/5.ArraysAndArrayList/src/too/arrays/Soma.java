package too.arrays;

import static javax.swing.JOptionPane.*;

/**
 * Realiza a soma dos números reais passados como parâmetros para o programa na linha de comando do 
 * sistema operacional. Exibe o resultado no console (opção padrão) ou em uma caiCxa de diálogo se a opção 
 * /g ou /G for fornecida.
 * A opção /g ou /G pode ser passada como argumento em qualquer ordem após o nome do programa.
 * 
 * ATENÇÃO: Exemplos de uso, via linha de comando, considerando a localização do projeto Arrays em 
 * 					   C:\TSI\2023 - 01\TOO\Projetos, o código fonte da classe Soma armazenada no pacote 
 * 					   too.arrays e os bytecodes (Soma.class) no diretório bin. 
 * 
 * 		C:\> java -cp "C:\TSI\2023 - 01\TOO\Projetos\5.ArraysAndArrayList\bin" too.array.Soma
 * 		
 * 		C:\TSI\2023 - 01\TOO\Projetos\5.ArraysAndArrayList\bin> java -cp . too.array.Soma 6.5 9.8
 * 		C:\TSI\2023 - 01\TOO\Projetos\5.ArraysAndArrayList\bin> java -cp . too.array.Soma 6.5 9.8 /g
 */
public class Soma 
{
	public static void main(String[] args) 
	{
		soma(args);
	}

	/**
	 * Realiza a soma dos argumentos do programa e exibe o resultado no console. 
	 * Exibe em uma caixa de diálogo se o parâmetro /g ou /G for fornecido ao programa.
	 */
	public static void soma(String[] argumentos) 
	{
		// Verifica se foi passado pelo menos dois argumentos.
		if (argumentos.length >= 2) {
			boolean gui = verificarOpcaoGui(argumentos);
			float numeros[] = converterArgumentos(argumentos); 

			if (gui) {
				showMessageDialog(null, String.format("A soma = %1.2f", soma(numeros)), "Soma", 
						                               INFORMATION_MESSAGE);
				System.exit(0);
			}
			else
				System.out.printf("\nA soma = %1.2f\n\n", soma(numeros));
		}
		else
			System.out.println("\nVocê deve fornecer pelo menos dois números.\n\n");
	}

	/**
	 * Converte os argumentos strings do programa para números reais.
	 * Retorna um vetor com os números reais.
	 */
	private static float[] converterArgumentos(String[] argumentos) 
	{
		float numeros[] = new float[argumentos.length];
		
		for (int indice = 0; indice < argumentos.length; indice++)
				if (!argumentos[indice].equalsIgnoreCase("/g"))
					numeros[indice] = Float.parseFloat(argumentos[indice]);
		
		return numeros;
	}
	
	/**
	 * Verifica se a opção /g ou /G foi passada como argumento, se sim retorna true, caso contrário, false.
	 */
	private static boolean verificarOpcaoGui(String[] argumentos) 
	{
		for (String argumento : argumentos)
			if (argumento.equalsIgnoreCase("/g"))
				return true;
		return false;
	}
	
	/**
	 * Calcula e retorna a soma dos números reais.
	 */
	public static float soma(float... numeros) 
	{
		float soma = 0;
		
		for (float numero : numeros)
			soma += numero;
		
		return soma;
	}
	
} // class Soma

