package too.heranca.formageometrica;

public class Forma 
{
	public static final String CENTIMETRO = "cm",
							   CENTIMETRO_QUADRADO = "cm²",
							   METRO = "m",
							   METRO_QUADRADO = "m²";
	
	public double area()
	{
		return 0.0;
	}
	
	@Override
	public String toString() 
	{
		return "Forma";
	}
	
	public String getNome()
	{
		return "Forma";
	}
	
} // class Forma
