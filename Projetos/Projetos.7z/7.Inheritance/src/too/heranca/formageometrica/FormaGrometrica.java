package too.heranca.formageometrica;

import java.awt.Color;

public class FormaGrometrica extends Forma
{
	private String nome;
	private Color cor;
	
	public FormaGrometrica() 
	{
		super(); 			// Chamada explícita ao construtor da superclasse Forma.
		nome = "";
		cor = Color.BLACK;
	}

	public FormaGrometrica(String nome, Color cor) 
	{
		/*
		 * Chamada implícita ao construtor da superclasse Forma. O Java SEMPRE invoca
		 * o construtor da superclasse direta.
		 */
		
		this.nome = nome;
		this.cor = cor;
	}

	public void setNome(String nome) 
	{
		this.nome = nome;
	}

	public Color getCor() 
	{
		return cor;
	}

	public void setCor(Color cor) 
	{
		this.cor = cor;
	}

	@Override
	public String getNome() 
	{
		return nome;
	}

	
	@Override
	public double area() 
	{
		return super.area();
	}

	@Override
	public String toString() 
	{
		// Chamada explícita ao método toString() da superclasse Forma.
		return String.format("%s: FormaGrometrica", super.toString());
	}

	
	
} // class FormaGrometrica
