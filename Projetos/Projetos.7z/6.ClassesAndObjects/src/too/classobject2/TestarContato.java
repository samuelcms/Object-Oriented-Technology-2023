package too.classobject2;

public class TestarContato
{
	public static void main(String[] args)
	{
		testarContato();
	}

	public static void testarContato()
	{
		/*
		 * 
		 * É possível acessar os atributos da classe diretamente quando o tipo 
		 * de acesso for 'pacote'.
		 * 
		 * Exemplo: 
		 * 
		 * 		contato.tipo = Contato.E_MAIL;
		 *		contato.contato = "email@email.com";
		 */
				
		Contato contato = new Contato();		
		TipoContato email = TipoContato.E_MAIL;

		contato.setTipo(TipoContato.E_MAIL);
		contato.setInfoContato("email@email.com");
		
		System.out.println(email);
		System.out.println(contato);		
		System.out.printf("%s: %s", contato.getTipo(), contato.getInfoContato());
		
	} // testarContato()

} // class TestarContato
