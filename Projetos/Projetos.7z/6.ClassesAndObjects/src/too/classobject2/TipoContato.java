package too.classobject2;

public enum TipoContato 
{
	E_MAIL("E-mail"),
	CELULAR("Celular"),
	TELEFONE("Telefone"),
	ENDERECO("Endereço");
	
	private String tipo;
	
	TipoContato(String tipo) 
	{
		this.tipo = tipo;
	}

	public String getTipo() 
	{
		return tipo;
	}

	public void setTipo(String tipo) 
	{
		this.tipo = tipo;
	}
	
	@Override
	public String toString()
	{
		return tipo;
	}
	
} // enum TipoContato
