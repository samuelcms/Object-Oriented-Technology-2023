package too.classobject2;

import java.util.ArrayList;
import java.util.List;

public class Cliente 
{
	private String nome;
	private String cpf;
	private List<Contato> listaContatos;
	
	public Cliente()
	{
		listaContatos = new ArrayList<>();
	}

	public Cliente(String nome, String cpf) 
	{
		this();
		this.nome = nome;
		this.cpf = cpf;
	}

	public String getNome() 
	{
		return nome;
	}

	public void setNome(String nome) 
	{
		this.nome = nome;
	}

	public String getCpf() 
	{
		return cpf;
	}

	public void setCpf(String cpf) 
	{
		this.cpf = cpf;
	}
	
	@Override
	public String toString() 
	{
		StringBuilder infoCliente = new StringBuilder();
		
		infoCliente.append(String.format("Cliente: %s, CPF: %s \n", nome, cpf));
		
		for(Contato contato : listaContatos)
			infoCliente.append(contato.toString() + "\n");
		
		return infoCliente.toString();
	}
	
	public void definirContato(TipoContato tipoContato, String informacao)
	{
		listaContatos.add(new Contato(tipoContato, informacao));		
	}
	
	public void alterarValorContato(TipoContato tipoContato, String infoAtual, String InfoNova)
	{
		for(Contato contato : listaContatos)
			if(contato.getTipo() == tipoContato && contato.getInfoContato().equalsIgnoreCase(infoAtual))
				contato.setInfoContato(InfoNova);
	}
	
	// Obtém todos os contatos associados a um tipo.
	public List<String> consultarContato(TipoContato tipoContato)
	{
		List<String> contatos = new ArrayList<>();

		for(Contato contato : listaContatos)
			if(contato.getTipo() == tipoContato)
				contatos.add(contato.getInfoContato());
		
		return contatos;
	}
	
} // class Cliente

/**
 * Esta classe possui o acesso default do Java, ou seja, o acesso de pacote. O acesso 
 * de pacote permite que a classe seja acessada por todas as classes que estão no mesmo 
 * pacote.
 * 
 * O objetivo da classe COntato é representar as diversas formas de contato de uma pesssoa
 * física ou de uma pessoa jurídica.
 * 
 */
class Contato
{	
	private TipoContato tipo;	// Tipo do campo (E-mail, Telefone, Endereço)
	private String infoContato;		// Valor do campo (email@email.com, (33)3333-3333, Barbacena).
		
	public Contato(){}
	
	public Contato(TipoContato tipo, String contato) 
	{
		this.tipo = tipo;
		this.infoContato = contato;
	}

	public TipoContato getTipo() 
	{
		return tipo;
	}
	
	public void setTipo(TipoContato tipo) 
	{
		this.tipo = tipo;
	}
	
	public String getInfoContato() 
	{
		return infoContato;
	}
	
	public void setInfoContato(String contato) 
	{
		this.infoContato = contato;
	}

	@Override
	public String toString() 
	{
		return String.format("%s: %s", tipo.getTipo(), infoContato);
	}
		
} // class Contato

