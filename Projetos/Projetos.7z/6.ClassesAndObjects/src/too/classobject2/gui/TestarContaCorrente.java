package too.classobject2.gui;

import too.classobject2.Cliente;
//import too.classobject2.ContaCorrente;
import too.classobject2.TipoContato;

public class TestarContaCorrente 
{
	/*
		System.out.println(Integer.class); 				   // Exibe o nome da classe juntamente com seu pacote.
		System.out.println(Integer.class.getSimpleName()); // Exibe apenas o nome da classe.
	*/
	
	public static void main(String[] args) 
	{
		testarContaCorrente();
	}

	public static void testarContaCorrente() 
	{
		Cliente cliente = new Cliente("Cliente 1", "123.456.789-10");
		// ContaCorrente contaCorrente = new ContaCorrente(cliente, 1000);
				
		cliente.definirContato(TipoContato.E_MAIL, "cliente.email1@email.com");
		cliente.definirContato(TipoContato.E_MAIL, "cliente.email2@email.com");
		cliente.definirContato(TipoContato.ENDERECO, "Nome da rua, número, bairro, cidade - UF");
		
		System.out.println(cliente);
		
	}
		
} // class TestarContaCorrente
