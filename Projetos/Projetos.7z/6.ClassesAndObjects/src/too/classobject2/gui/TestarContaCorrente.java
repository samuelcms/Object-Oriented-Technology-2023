package too.classobject2.gui;

public class TestarContaCorrente 
{
	/*
		System.out.println(Integer.class); 				   // Exibe o nome da classe juntamente com seu pacote.
		System.out.println(Integer.class.getSimpleName()); // Exibe apenas o nome da classe.
	*/
	
	public static void main(String[] args) 
	{
		testarContaCorrente();
	}

	public static void testarContaCorrente() 
	{

	}
		
} // class TestarContaCorrente
