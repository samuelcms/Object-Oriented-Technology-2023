package too.classobject2;

public class ContaCorrente 
{
	private Cliente titular;
	private int numeroConta;
	private double valor;
										   
	private static int geradorNumeroConta,
					   quantidadeContas;	// Quantidade de contas correntes criadas.
	
	public ContaCorrente()
	{
		this(new Cliente(), 0.0);
	}
	
	/**
	 * Cria uma conta corrente com titular e valor inicial especificados.
	 * 
	 * @param cliente Nome do titular da conta.
	 * @param valor Valor de depósito inicial na conta.
	 */
	public ContaCorrente(Cliente cliente, double valor) 
	{
		setCliente(cliente);
		deposito(valor);
		
		numeroConta = ++geradorNumeroConta;
		quantidadeContas++;
	}

	public Cliente getCliente() 
	{
		return titular;
	}

	public boolean setCliente(Cliente titular) 
	{
		if(titular != null)
		{
			this.titular = titular;
			return true;
		}
		
		return false;
	}

	public int getNumeroConta() 
	{
		return numeroConta;
	}

	public static int getQuantidadeContas() 
	{
		return quantidadeContas;
	}

	@Override
	public String toString() 
	{
		return String.format("%s: %,d, %s, R$: %,.2f", getClass().getSimpleName(), numeroConta, titular, valor);
	}
	
	// Obtém o valor atual disponível na conta.
	public double saldo() 
	{
		return valor;
	}
	
	/**
	 * Operação para depositar um valor na conta corrente.
	 *  
	 * @param valorDeposito Valor que será depositado.
	 * 
	 * @return Retorna verdadeiro se a operação for concluída com sucesso, ou false, caso o valor fornecido 
	 * 		   for inválido, ou seja, negativo.
	 */
	public boolean deposito(double valorDeposito)
	{
		if(valor > 0)
		{
			valor += valorDeposito;
			return true;
		}
			
		return false;
	}
	
	/**
	 * Operação para resgatar um valor na conta corrente.
	 * 
	 * @param valorSaque Valor que será resgatado.
	 * 
	 * @return Retorna verdadeiro se a operação for concluída com sucesso, ou false, caso o valor fornecido 
	 * 		   for inválido, ou seja, negativo ou superior ao valor disponível em conta.
	 */
	public boolean saque(double valorSaque)
	{
		if(valor > 0 && valor >= valorSaque)
		{
			valor -= valorSaque;
			return true;
		}
		return false;
	}
	
} // class ContaCorrente
