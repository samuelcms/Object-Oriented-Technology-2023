package too.classobject1.gui;

import too.classobject1.Produto;
import static too.classobject1.gui.EntradaESaida.*;

public class TestarProduto 
{
	public static void main(String[] args)
	{
		testarProduto();
		System.exit(0);
	}

	public static void testarProduto() 
	{
		String resultado = "";
		Produto carro = new Produto(),
				pc = new Produto("Dell PC Gamer", 1, 8999);
		
		carro.setNome("La Ferrari");
		carro.setQuantidade(1);
		carro.setPreco(14000000);
		
		resultado = carro + "\n" + pc;
		resultado += "\n\n" + obterProduto(carro) + "\n\n" + obterProduto(pc);
		
		msgInfo(resultado, "Teste da classe Produto");
	}
	
	/**
	 * Obtem uma representação String com os dados do produto.
	 *  
	 * @param produto Objeto da classe produto.
	 * 
	 * @return representação string dos atributos do objeto.
	 */
	public static String obterProduto(Produto produto)
	{
		return String.format("Nome: %s\nQuantidade: %,d\nPreço: R$ %,.2f", produto.getNome(), produto.getQuantidade(), produto.getPreco());	
	}
	
} // class TestarProduto
