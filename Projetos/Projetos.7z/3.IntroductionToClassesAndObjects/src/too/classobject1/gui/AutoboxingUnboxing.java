package too.classobject1.gui;

import static too.classobject1.gui.EntradaESaida.*;

public class AutoboxingUnboxing 
{
	public static void main(String[] args)
	{
		autoboxingUnboxing();
		System.exit(0);
	}

	public static void autoboxingUnboxing()
	{
		// Autoboxing.
		Integer integer = 10;
		Boolean verdadeiro = true;
		final Double PI = Math.PI;
		
		// Unboxing.
		int inteiro = integer;
		boolean falso = verdadeiro;
		double pi = PI;
		
		msgInfo(String.format("%d, %b, %.6f", integer, verdadeiro, PI), "Autoboxing");
		msgInfo(String.format("%d, %b, %.6f", inteiro, falso, pi), "Unboxing");
	}

} // class AutoboxingUnboxing
