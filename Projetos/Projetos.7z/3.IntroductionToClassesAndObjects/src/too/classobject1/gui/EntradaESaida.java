package too.classobject1.gui;

import static javax.swing.JOptionPane.*;

public class EntradaESaida 
{
	/**
	 * Exibe uma mensagem de informação em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida.
	 * @param titulo Título da janela.
	 * 
	 * @see javax.swing.JOptionPane
	 */
	public static void msgInfo(String mensagem, String titulo) 
	{
		showMessageDialog(null, mensagem, titulo, INFORMATION_MESSAGE);		
	}

	/**
	 * Exibe uma mensagem de advertência em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida.
	 * @param titulo Título da janela.
	 * 
 	 * @see javax.swing.JOptionPane
	 */
	public static void msgAlerta(String mensagem, String titulo) 
	{
		showMessageDialog(null, mensagem, titulo, WARNING_MESSAGE);
	}
	
	/**
	 * Exibe uma mensagem de erro em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida.
	 * @param titulo Título da janela.
	 * 
 	 * @see javax.swing.JOptionPane
	 */
	public static void msgErro(String mensagem, String titulo) 
	{
		showMessageDialog(null, mensagem, titulo, ERROR_MESSAGE);
	}

	/**
	 * Lê uma string em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida na janela.
	 * @param titulo Título da janela.
	 * 
	 * @return Retorna a <code>String</code> lida na caixa de diálogo, ou null, quando a operação for cancelada.
 	 *
 	 * @see javax.swing.JOptionPane
	 */
	public static String lerString(String mensagem, String titulo) 
	{
		return showInputDialog(null, mensagem, titulo, QUESTION_MESSAGE);
	}
	
	/**
	 * Lê um número inteiro em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida na janela.
	 * @param titulo Título da janela.
	 * 
	 * @return Retorna o número lido na caixa de diálogo, ou null, quando a operação for cancelada.
	 * 
	 * @see javax.swing.JOptionPane
	 */
	public static Integer lerNumeroInteiro(String mensagem, String titulo) 
	{
		String str = lerString(mensagem, titulo);
		return ((str != null)) ? Integer.parseInt(str) : null;
	}
	
	/**
	 * Lê um número real em uma caixa de diálogo com título.
	 * 
	 * @param mensagem Mensagem exibida na janela.
	 * @param titulo Título da janela.
	 * 
	 * @return Retorna o número lido na caixa de diálogo, ou null, quando a operação for cancelada.
	 * 
	 * @see javax.swing.JOptionPane
	 */
	public static Double lerNumeroReal(String mensagem, String titulo) 
	{
		String str = lerString(mensagem, titulo);
		return ((str != null)) ? Double.parseDouble(str) : null;
	}

} // class EntradaESAida