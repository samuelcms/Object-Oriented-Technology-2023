package too.estruturascontrole.gui;

import static too.estruturascontrole.gui.EntradaESaida.*;

public class EstruturasControle 
{
	public static void main(String[] args) 
	{
		estruturasControle();
	}

	public static void estruturasControle() 
	{
		breakRotulado();
		continueRotulado();
		System.exit(0);
	}

	public static void continueRotulado() 
	{
		Integer numeroInt = null;
		final String NOME_MODULO = "Números Inteiros Pares";
		
		LOOP_FOR: // Rótulo.
		
			for(int numero = 0; numero < 3; numero++)
			{
				while(true)
				{
					numeroInt = lerNumeroInteiro("Número: ", NOME_MODULO);

					if(numeroInt != null)
					{
						if(!isImpar(numeroInt)) {msgInfo(String.format("O número %d é par", numeroInt), NOME_MODULO);}
						else {msgInfo(String.format("O número %d é ímpar", numeroInt), NOME_MODULO);}
					}
					
					else break LOOP_FOR;
					continue LOOP_FOR; // Break rotulado.
				}
			}
		
	} // continueRotulado

	public static void breakRotulado() 
	{
		Integer numeroInt;
		final String NOME_MODULO = "Números Inteiros Ímpares";
		
		LOOP_FOR: // Rótulo.
		{
			for(int numero = 0; numero < Byte.MAX_VALUE; numero++)
			{
				do 
				{
					numeroInt = lerNumeroInteiro("Número: ", NOME_MODULO);
					
					if(numeroInt != null)
					{
						if(isImpar(numeroInt)) msgInfo(String.format("O número %d é ímpar", numeroInt), NOME_MODULO);
						else msgErro(String.format("O número %d é par", numeroInt), NOME_MODULO);
					}
					
					else break LOOP_FOR; // Break rotulado.
					
				}while(numeroInt != null);
			}
		}
	
	} // breakRotulado

	public static boolean isImpar(Integer numeroInt) 
	{
		return (numeroInt%2 != 0)? true : false;
	}

} // class EstruturasControle
