package too.enumeracao;

import java.util.EnumSet;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import static too.enumeracao.gui.EntradaESaida.*;
import static java.lang.String.format;

public class Enumeracao 
{
	/* Até o Java 15 a enumeração deve ser definida no nível de classe como uma variável de instância ou de classe.
	 *
	 * 	private static enum REGIOES_DO_BRASIL {CENTRO_OESTE, NORDESTE, NORTE, SUDESTE, SUL};
	 */

	public static void main(String[] args)
	{
		enumeracao();
		System.exit(0);
	}

	public static void enumeracao() 
	{
		// A partir do Java 16 tornou-se possível definir uma enumeração como um tipo local.
		enum REGIOES_DO_BRASIL {CENTRO_OESTE, NORDESTE, NORTE, SUDESTE, SUL};

		REGIOES_DO_BRASIL brasil = REGIOES_DO_BRASIL.CENTRO_OESTE;
		System.out.println(brasil.toString());
		System.out.println(brasil.toString());

		writTextArea("\n- Regiões do Brasil\n");

		// Exibe a lista de constantes da enumeração.
		for (REGIOES_DO_BRASIL regiao : REGIOES_DO_BRASIL.values())
			writTextArea(format("\t%d = %s\n", regiao.ordinal(), regiao.name()));

		writTextArea("\n- Regiões do Sul do Brasil\n");

		// Exibe um subconjunto da lista de constantes da enumeração.
		for (REGIOES_DO_BRASIL regiao : EnumSet.range(REGIOES_DO_BRASIL.SUDESTE, REGIOES_DO_BRASIL.SUL))
			writTextArea(format("\t%d = %s\n", regiao.ordinal(), regiao.name()));

		writTextArea("\n- Regiões do Norte do Brasil\n");

		// Exibe um subconjunto da lista de constantes da enumeração.
		for (REGIOES_DO_BRASIL regiao : EnumSet.range(REGIOES_DO_BRASIL.NORDESTE, REGIOES_DO_BRASIL.NORTE))
			writTextArea(format("\t%d = %s\n", regiao.ordinal(), regiao.name()));

		/* 
		 * TesouroDireto td = new TesouroDireto();  // ERRO: A enumeração é um tipo de dado não instanciável.
		 */

		exibirEnumeracao("\n- Títulos do Tesouro Direto\n", TesouroDireto.values());

		// Modifica os atributos da constante TESOURO_SELIC da enumeração TesouroDireto.
		TesouroDireto.TESOURO_SELIC.setTitulo("Tesouro Selic 2027");
		TesouroDireto.TESOURO_SELIC.setDataDeVencimento("01/03/2027");
		TesouroDireto.TESOURO_SELIC.setTaxa(0.3171);
		TesouroDireto.TESOURO_SELIC.setValorMinimo(106.9);
		TesouroDireto.TESOURO_SELIC.setPrecoUnitario(10690.21);

		// Exibe os novos atributos da constante TESOURO_SELIC da enumeração TesouroDireto.
		exibirEnumeracao("- Título pós-fixado indexado a Selic\n", TesouroDireto.TESOURO_SELIC);

		// Define uma variável do tipo da enumeração TesouroDireto e exibe os seus atributos.
		TesouroDireto tesouroIPCA = TesouroDireto.TESOURO_IPCA;
		
		JTextArea textArea = exibirEnumeracao("\n- Título pós-fixado indexado ao IPCA\n", tesouroIPCA);
		
		msgInfo(new JScrollPane(textArea), LINHA_VAZIA);
	} // enumeracao()

	public static JTextArea exibirEnumeracao(String mensagem, Object[] enumeracoes) 
	{
		JTextArea textArea =  writTextArea(mensagem);

		for (Object enumeracao : enumeracoes)
			writTextArea(enumeracao.toString() + NOVA_LINHA);
		
		return textArea;
	}

	public  static JTextArea exibirEnumeracao(String mensagem, TesouroDireto tesouroDireto) 
	{			
		return writTextArea(format("%s\n%s", mensagem, tesouroDireto.toString()));
	}


} // class Enumeracao
