package too.enumeracao;

import java.util.EnumSet;

public class Enumeracao 
{
	/* Até o Java 15 a enumeração deve ser definida no nível de classe como uma variável de instância ou de classe.
	 *
	 * 	private static enum REGIOES_DO_BRASIL {CENTRO_OESTE, NORDESTE, NORTE, SUDESTE, SUL};
	 */

	public static void main(String[] args)
	{
		enumeracao();
	}

	public static void enumeracao() 
	{
		// A partir do Java 16 tornou-se possível definir uma enumeração como um tipo local.
		enum REGIOES_DO_BRASIL {CENTRO_OESTE, NORDESTE, NORTE, SUDESTE, SUL};

		REGIOES_DO_BRASIL brasil = REGIOES_DO_BRASIL.CENTRO_OESTE;
		System.out.println(brasil);
		System.out.println(brasil.toString());

		System.out.println("\n- Regiões do Brasil\n");

		// Exibe a lista de constantes da enumeração.
		for (REGIOES_DO_BRASIL regiao : REGIOES_DO_BRASIL.values())
			System.out.printf("\t%d = %s\n", regiao.ordinal(), regiao.name());

		System.out.println("\n- Regiões do Sul do Brasil\n");

		// Exibe um subconjunto da lista de constantes da enumeração.
		for (REGIOES_DO_BRASIL regiao : EnumSet.range(REGIOES_DO_BRASIL.SUDESTE, REGIOES_DO_BRASIL.SUL))
			System.out.printf("\t%d = %s\n", regiao.ordinal(), regiao.name());

		System.out.println("\n- Regiões do Norte do Brasil\n");

		// Exibe um subconjunto da lista de constantes da enumeração.
		for (REGIOES_DO_BRASIL regiao : EnumSet.range(REGIOES_DO_BRASIL.NORDESTE, REGIOES_DO_BRASIL.NORTE))
			System.out.printf("\t%d = %s\n", regiao.ordinal(), regiao.name());

		/* 
		 * TesouroDireto td = new TesouroDireto();  // ERRO: A enumeração é um tipo de dado não instanciável.
		 */

		exibirEnumeracao("\n- Títulos do Tesouro Direto\n", TesouroDireto.values());

		// Modifica os atributos da constante TESOURO_SELIC da enumeração TesouroDireto.
		TesouroDireto.TESOURO_SELIC.setTitulo("Tesouro Selic 2027");
		TesouroDireto.TESOURO_SELIC.setDataDeVencimento("01/03/2027");
		TesouroDireto.TESOURO_SELIC.setTaxa(0.3171);
		TesouroDireto.TESOURO_SELIC.setValorMinimo(106.9);
		TesouroDireto.TESOURO_SELIC.setPrecoUnitario(10690.21);

		// Exibe os novos atributos da constante TESOURO_SELIC da enumeração TesouroDireto.
		exibirEnumeracao("- Título pós-fixado indexado a Selic\n", TesouroDireto.TESOURO_SELIC);

		// Define uma variável do tipo da enumeração TesouroDireto e exibe os seus atributos.
		TesouroDireto tesouroIPCA = TesouroDireto.TESOURO_IPCA;
		exibirEnumeracao("\n- Título pós-fixado indexado ao IPCA\n", tesouroIPCA);
	} // enumeracao()

	public static void exibirEnumeracao(String mensagem, Object[] enumeracoes) {
		System.out.println(mensagem);

		for (Object enumeracao : enumeracoes)
			System.out.println(enumeracao);
	}

	public  static void exibirEnumeracao(String mensagem, TesouroDireto tesouroDireto) {
		System.out.printf("%s\n%s", mensagem, tesouroDireto.toString());
	}


} // class Enumeracao
