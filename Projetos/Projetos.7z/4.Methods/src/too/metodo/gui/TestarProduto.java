package too.metodo.gui;

import too.metodo.Produto;
import static java.lang.String.format;
import static too.metodo.gui.EntradaESaida.*;

public class TestarProduto
{

	public static void main(String[] args) 
	{
		testarProduto();
	}

	public static void testarProduto() 
	{
		// 'var' faz inferência de tipo.
		final var NOVA_LINHA = '\n';
		final var SEPARADOR_LINHA = "\n\n";
		
		StringBuilder resultadoBuilder = new StringBuilder();
		resultadoBuilder.append(format("Quantidade de produtos: %d", Produto.getQuantidadeProduto()));
		
		Produto hamburguer = new Produto(), arroz = new Produto("Arroz", 15, 35.00f), feijao = new Produto("Feijão", 15, 19.00f);
		
		hamburguer.setNome("X-Tudo");
		hamburguer.setPreco(22.90f);
		hamburguer.setQuantidade(2);

		resultadoBuilder.append(format("%s  - %s%s", SEPARADOR_LINHA, obterProduto(hamburguer), NOVA_LINHA));
		resultadoBuilder.append(format("  - %s%s", obterProduto(arroz), NOVA_LINHA));
		resultadoBuilder.append(format("  - %s%s", obterProduto(feijao), NOVA_LINHA));
		resultadoBuilder.append(format("\nQuantidade de produtos: %d", Produto.getQuantidadeProduto()));
		
		msgInfo(resultadoBuilder.toString(), "Produtos");
		System.exit(0);
	
	} // testarProduto()

	/**
	 * Obtem uma representação String com os dados do produto.
	 *  
	 * @param produto Objeto da classe produto.
	 * 
	 * @return representação string dos atributos do objeto.
	 */
	public static String obterProduto(Produto produto)
	{
		return String.format("Código: %03d Nome: %s, Quantidade: %,d, Preço: R$ %,.2f", produto.CODIGO_PRODUTO, produto.getNome(), produto.getQuantidade(), produto.getPreco());	
	}

} // class TestarProduto
