package too.metodo;

public class Produto
{
	/*
	 * Variáveis de classe e de instância são inicializadas automaticamente. 
	 * 	
	 * 		- Variáveis de tipo primitivo são inicializadas com 0 (false, caso sejam bool);
	 * 		- Variáveis de tipo por referência são inicializadas com 'null'. 
	 */
	
	// Variáveis de classe.
	private static int gerarCodigo,				// Usada para gerar um código único para cada produto.
					   quantidadeProduto;		// Contabiliza a quantidade de produtos criados.
	
	// Variáveis de instância.
	private String nome;
	private int quantidade;
	private float preco;
	
	public final int CODIGO_PRODUTO;	

	// Construtor default.
	public Produto() 
	{
		nome = "";
		CODIGO_PRODUTO = ++gerarCodigo;
		quantidadeProduto++;
	}

	public Produto(String nome) 
	{
		this();
		this.nome = nome;
	}
	
	// Construtor sobrecarregado.
	public Produto(String nome, int quantidade, float preco) 
	{
		this(nome);
		this.quantidade = quantidade;
		this.preco = preco;
	}
	
	public String getNome() 
	{
		return nome;
	}
	
	public void setNome(String nome) 
	{
		this.nome = nome;	
	}
	
	public int getQuantidade() 
	{
		return quantidade;
	}
	
	public void setQuantidade(int quantidade) 
	{
		this.quantidade = quantidade;
	}
	
	public float getPreco() 
	{
		return preco;
	}
	
	public void setPreco(float preco) 
	{
		this.preco = preco;
	}
	
	// Obtém a quantidade de objetos da classe Produto que foram criados.
	public static int getQuantidadeProduto() 
	{		
		return quantidadeProduto;
	}

	@Override
	public String toString() 
	{
		return String.format("%03d, %s, %,d, R$ %,.2f", CODIGO_PRODUTO, nome, quantidade, preco);
	}
			
} // class Produto
