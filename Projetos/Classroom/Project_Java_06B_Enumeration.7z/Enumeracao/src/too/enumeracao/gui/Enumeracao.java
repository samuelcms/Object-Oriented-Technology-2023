package too.enumeracao.gui;

import java.util.EnumSet;

import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import too.enumeracao.TesouroDireto;

import static too.enumeracao.gui.EntradaSaida.*;

public class Enumeracao {
	/* Até o Java 15 a enumeração deve ser definida no nível de classe como uma variável de instância ou de classe.
	 *
	 * 	private static enum REGIOES_DO_BRASIL {CENTRO_OESTE, NORDESTE, NORTE, SUDESTE, SUL};
	 */
	
	public static void main(String[] args) {
		enumeracao();
	}

	public static void enumeracao() {
		// A partir do Java 16 tornou-se possível definir uma enumeração como um tipo local.
		enum REGIOES_DO_BRASIL {CENTRO_OESTE, NORDESTE, NORTE, SUDESTE, SUL};
		
		REGIOES_DO_BRASIL brasil = REGIOES_DO_BRASIL.CENTRO_OESTE;
		System.out.println(brasil);
		System.out.println(brasil.toString());
		
		writeTextArea("- Regiões do Brasil\n");
		
		// Exibe a lista de constantes da enumeração.
		for (REGIOES_DO_BRASIL regiao : REGIOES_DO_BRASIL.values())
			writeTextArea(String.format("\t%d = %s\n", regiao.ordinal(), regiao.name()));
		
		writeTextArea("\n- Regiões do Sul do Brasil\n");
		
		// Exibe um subconjunto da lista de constantes da enumeração.
		for (REGIOES_DO_BRASIL regiao : EnumSet.range(REGIOES_DO_BRASIL.SUDESTE, REGIOES_DO_BRASIL.SUL))
			writeTextArea(String.format("\t%d = %s\n", regiao.ordinal(), regiao.name()));
		
		writeTextArea("\n- Regiões do Norte do Brasil\n");
		
		// Exibe um subconjunto da lista de constantes da enumeração.
		for (REGIOES_DO_BRASIL regiao : EnumSet.range(REGIOES_DO_BRASIL.NORDESTE, REGIOES_DO_BRASIL.NORTE))
			writeTextArea(String.format("\t%d = %s\n", regiao.ordinal(), regiao.name()));

		/* 
		 * // ERRO: A enumeração é um tipo de dado não instanciável.
		 * 
		 * TesouroDireto td = new TesouroDireto("", "", 0, 0, 0);  
		 */

		escreverEnumeracao("\n- Títulos do Tesouro Direto\n", TesouroDireto.values());
		
		// Modifica os atributos da constante TESOURO_SELIC da enumeração TesouroDireto.
		TesouroDireto.TESOURO_SELIC.setTitulo("Tesouro Selic 2027");
		TesouroDireto.TESOURO_SELIC.setDataDeVencimento("01/03/2027");
		TesouroDireto.TESOURO_SELIC.setTaxa(0.3171);
		TesouroDireto.TESOURO_SELIC.setValorMinimo(106.9);
		TesouroDireto.TESOURO_SELIC.setPrecoUnitario(10690.21);

		// Escreve os novos atributos da constante TESOURO_SELIC da enumeração TesouroDireto.
		escreverEnumeracao("- Título pós-fixado indexado a Selic\n", TesouroDireto.TESOURO_SELIC);

		// Define uma variável do tipo da enumeração TesouroDireto.
		TesouroDireto tesouroIPCA = TesouroDireto.TESOURO_IPCA;
		
		//  Obtém os atributos da enumeração.
		JTextArea textArea = escreverEnumeracao("\n- Título pós-fixado indexado ao IPCA\n", tesouroIPCA);
		
		// Exibe todo o conteúdo escrito na área de texto em uma caixa de diálogo.
		msgInfo(new JScrollPane(textArea), "Enumeração");
		
		/* Nas constantes dos comandos case abaixo deve-se usar a constante da enumeração sem qualificação, ou seja,
		 * não se pode usar a sintaxe: <TipoEnumeração>.<ConstanteEnumeração>.
		 */
		switch (tesouroIPCA) {
		case TESOURO_IPCA: break;
		case TESOURO_PREFIXADO: break;
		case TESOURO_SELIC: 
			
		System.exit(0);	
		}
	} // enumeracao()
	
	/**
	 * Escreve uma mensagem e os dados da enumeração na área de texto.
	 */
	public static JTextArea escreverEnumeracao(String mensagem, Object[] enumeracoes) {
		JTextArea textArea = writeTextArea(mensagem);
		
		for (Object enumeracao : enumeracoes)
			textArea = writeTextArea(enumeracao.toString() + NOVA_LINHA);
		
		return textArea;
	}

	/**
	 * Escreve uma mensagem e os dados da enumeração na área de texto.
	 */
	public  static JTextArea escreverEnumeracao(String mensagem, TesouroDireto tesouroDireto) {
		return writeTextArea(String.format("%s\n%s\n", mensagem, tesouroDireto.toString()));
	}
} // class Enumeracao 
