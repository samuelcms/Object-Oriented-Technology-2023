package too.enumeracao;

public enum TesouroDireto {
	// Lista de constantes da enumeração. Essas constantes são implicitamente públicas e estáticas. 
	TESOURO_IPCA("Tesouro IPCA+ 2024", "15/08/2024", 4.14, 50.92, 2546.23),
	TESOURO_PREFIXADO("Tesouro Prefixado 2022", "01/01/2022", 7.76, 32.37, 809.40),
	TESOURO_SELIC("Tesouro Selic 2025", "01/03/2025", 0.02, 99.73, 9973.67);
	
	private String titulo, dataDeVencimento;
	private double taxa, valorMinimo, precoUnitario;
	
	/* O construtor sem modificador de acesso é implicitamente privado, porque a enumeração não é um tipo
	 * instanciável.
	 */
	private TesouroDireto(String titulo, String dataDeVencimento, double taxa, double valorMinimo, 
											 double precoUnitario) {
		this.titulo = titulo;
		this.dataDeVencimento = dataDeVencimento;
		this.taxa = taxa;
		this.valorMinimo = valorMinimo;
		this.precoUnitario = precoUnitario;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getDataDeVencimento() {
		return dataDeVencimento;
	}

	public void setDataDeVencimento(String dataDeVencimento) {
		this.dataDeVencimento = dataDeVencimento;
	}

	public double getTaxa() {
		return taxa;
	}

	public void setTaxa(double taxa) {
		this.taxa = taxa;
	}

	public double getValorMinimo() {
		return valorMinimo;
	}

	public void setValorMinimo(double valorMinimo) {
		this.valorMinimo = valorMinimo;
	}

	public double getPrecoUnitario() {
		return precoUnitario;
	}

	public void setPrecoUnitario(double precoUnitario) {
		this.precoUnitario = precoUnitario;
	}

	@Override
	public String toString() {
		return String.format("  %s\n  Vencimento: %s\n  Taxa: %1.2f%% a.a.\n  Valor mínimo: R$ %1.2f\n  Preço unitário: R$ %,1.2f\n", titulo, dataDeVencimento, taxa,valorMinimo, precoUnitario);
	}
}
