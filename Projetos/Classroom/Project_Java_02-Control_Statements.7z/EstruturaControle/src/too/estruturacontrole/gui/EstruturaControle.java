package too.estruturacontrole.gui;

import static too.estruturacontrole.gui.EntradaSaida.*;

public class EstruturaControle {

	public static void main(String[] args) {
		estruturaControle();
	}

	public static void estruturaControle() {
		breakRotulado();
		continueRotulado();
		
		System.exit(0);
	}

	public static void continueRotulado() {
		Integer numeroInteiro = null;
		final String NOME_MODULO = "Números Inteiros Pares";
		
		LOOP_FOR: // início do bloco rotulado LOOP_FOR
				for (int numero = 1; numero <= 3; numero++) 
					while (true) {
						numeroInteiro = lerNumeroInteiro("Número par:", NOME_MODULO);

						if (numeroInteiro != null) 
							if (numeroInteiro % 2 == 0)
								msgInfo(String.format("O número %d é par.", numeroInteiro), NOME_MODULO);
							else
								msgErro(String.format("O número %d é ímpar.", numeroInteiro), NOME_MODULO);
						else
							break LOOP_FOR;
						continue LOOP_FOR;
					}
	} // continueRotulado()

	public static void breakRotulado() {
		Integer numeroInteiro;
		final String NOME_MODULO = "Números Inteiros Ímpares";
		
		LOOP_FOR: { // início do bloco rotulado LOOP_FOR
			
			for (int numero = 0; numero < Integer.MAX_VALUE; numero++) 
				do { numeroInteiro = lerNumeroInteiro("Número ímpar:", NOME_MODULO);

				if (numeroInteiro != null) 
					if (numeroInteiro % 2 != 0)
						msgInfo(String.format("O número %d é ímpar.", numeroInteiro), NOME_MODULO);
					else
						msgErro(String.format("O número %d é par.", numeroInteiro), NOME_MODULO);
				else
					break LOOP_FOR;
				} while (numeroInteiro != null);
		} // fim do bloco rotulado LOOP_FOR
	} // breakRotulado()
} // class EstruturaControle