package too.estruturacontrole;

import java.util.Scanner;

public class SwitchWithString {

	public static void main(String[] args) {
		switchWithString();
	}

	public static void switchWithString() {
		Scanner scanner = new Scanner(System.in);
		
		// Loop infinito, será?
		while (true) {
			// Lê o dia da semana.
			System.out.printf("Dia da semana: ");
			String diaSemana = scanner.nextLine();
			
			// Verifica se o usuário deseja encerrar o programa.
			if (diaSemana.equalsIgnoreCase("fim")) break;
			
			switch (diaSemana.toLowerCase()) {
			case "segunda-feira":
			case "terça-feira":
			case "quarta-feira":
			case "quinta-feira":
			case "sexta-feira":
			case "sábado":
			case "domingo": System.out.println("Dia da semana válido."); break;
			default:
				System.err.println("Dia da semana inexistente.");
			}
		}
		scanner.close();
	}
}
