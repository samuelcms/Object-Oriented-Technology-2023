package too.heranca.formageometrica;

/**
 * Forma é o tipo base da hierarquia de classes deste projeto. 
 */
public class Forma {
	public static final String 
		CENTIMETRO = "cm",
		CENTIMETRO_QUADRADO = "cm²",
		METRO = "m",
		METRO_QUADRADO = "m²";
	
	public double area() {
		return 0;
	}

	// Sobrescreve o método toString da superclasse direta java.lang.Object.
	@Override
	public String toString() {
		return "Forma";
	}
	
	public String getNome() {
		return "Forma";
	}
} // class Forma
