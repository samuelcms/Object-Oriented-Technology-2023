package too.heranca.formageometrica.gui;

import static too.heranca.formageometrica.gui.EntradaSaida.*;

import java.awt.Color;

import javax.swing.JScrollPane;

import too.heranca.formageometrica.Circulo;
import too.heranca.formageometrica.Forma;
import too.heranca.formageometrica.Forma2D;
import too.heranca.formageometrica.Forma3D;
import too.heranca.formageometrica.FormaGeometrica;
import too.heranca.formageometrica.Quadrado;
import too.heranca.formageometrica.Triangulo;

public class FormasGeometricas {

	public static void main(String[] args) {
		formasGeometricas();
	}

	/**
	 * Testa a hierarquia de classes sobre as Formas Geométricas.
	 */
	public static void formasGeometricas() {
		Forma forma = new Forma();
		FormaGeometrica formaGeometrica = new FormaGeometrica();
		Forma2D forma2D = new Forma2D();
		Forma3D forma3D = new Forma3D();
		Quadrado quadrado = new Quadrado(5);
		Circulo circulo = new Circulo(8);
		Triangulo triangulo = new Triangulo();
		
		/* Não se pode usar a referência da superclasse para invocar um método específico da subclasse, ou seja, um
		     método que não existe na superclasse, apenas na subclasse. 
		  
				forma.setLado(3);
				formaGeometrica.setLado(3);
				forma2D.setLado(3);
		*/
		
		// Define os atributos dos objetos via chamada encadeada de métodos.
		formaGeometrica.setNome("Forma Geométrica").setColor(Color.BLUE);
		triangulo.setAltura(32).setBase(16).setNome("Triângulo Isósceles").setUnidade(Forma.METRO);
		
		// Exibe os atributos dos objetos.
		writeTextArea(forma.toString());
		writeTextArea(NOVA_LINHA);
		writeTextArea(formaGeometrica.toString());
		writeTextArea(NOVA_LINHA);
		writeTextArea(forma2D.toString());
		writeTextArea(NOVA_LINHA);
		writeTextArea(forma3D.toString());
		writeTextArea(LINHA_VAZIA);		
		writeTextArea(String.format("Nome: %s, Cor: %s", formaGeometrica.getNome(), formaGeometrica.getColor()));
		writeTextArea(LINHA_VAZIA);
		writeTextArea(quadrado.toString());
		writeTextArea(NOVA_LINHA);
		writeTextArea(circulo.toString());
		writeTextArea(NOVA_LINHA);
		writeTextArea(triangulo.toString());
		writeTextArea(
				String.format("\n\nÁrea das Formas Geométricas\n\n\t%s = %,1.2f %s\n\t%s = %,1.2f %s\n\t%s = %,1.2f %s",
										 quadrado.getNome(), quadrado.area(), FormaGeometrica.obterUnidadeArea(quadrado), 
										 circulo.getNome(), circulo.area(), circulo.obterUnidadeArea(),
										 triangulo.getNome(), triangulo.area(), triangulo.obterUnidadeArea()
										 )
								);

		// Todo objeto de subclasse é um objeto de superclasse, ou seja, usa o relacionamento "é um" da herança.
		forma = triangulo;
		
		writeTextArea(LINHA_VAZIA);
		writeTextArea(forma.toString());
		writeTextArea(LINHA_VAZIA);
		
		// Verifica se a variável forma possui a referência de um objeto da classe Quadrado.
		if (forma instanceof Quadrado) {
			// Faz um downcast, ou seja, converte a referência da superclasse na referência da subclasse.
			quadrado = (Quadrado) forma;
			
			writeTextArea(quadrado.toString());
		}
		else
			writeTextArea("A variável forma não possui a referência da classe Quadrado.");
		
		// Todo objeto de subclasse é um objeto de superclasse, ou seja, usa o relacionamento "é um" da herança.
		forma = quadrado;

		writeTextArea(LINHA_VAZIA);
		// Verifica se variável forma possui a referência de um objeto da classe Quadrado.
		if (forma instanceof Quadrado) {
			// Faz um downcast, ou seja, converte a referência da superclasse na referência da subclasse.
			quadrado = (Quadrado) forma;
			
			writeTextArea(quadrado.toString());
		}
		else
			writeTextArea("A variável forma não possui a referência da classe Quadrado.");

		// Exibe os atributos dos objetos na caixa  de diálogo.
		msgInfo(new JScrollPane(getTextArea()), "Formas Geométricas");
		
		// Finaliza o programa Java GUI.
		System.exit(0);
	} // formasGeometricas()
} // class FormasGeometricas
