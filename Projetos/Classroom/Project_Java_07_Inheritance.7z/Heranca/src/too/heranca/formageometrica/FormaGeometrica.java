package too.heranca.formageometrica;

import java.awt.Color;

public class FormaGeometrica extends Forma  {
	protected String nome;
	protected Color color;
	protected String unidade;
	
	public FormaGeometrica() {
		// Chamada explícita ao construtor default da superclasse Forma.
		super(); 
		
		nome = "Forma Geométrica";
		color = Color.BLACK;
		unidade = CENTIMETRO;
	}

	public FormaGeometrica(String nome, Color color) {
		// Chamada implícita ao construtor default da superclasse Forma.
		
		this.nome = nome;
		this.color = color;
		unidade = CENTIMETRO;
	}
	
	public FormaGeometrica(String nome, Color color, String unidade) {
		// Chamada explícita ao construtor default da superclasse Forma.
		super();
		
		this.nome = nome;
		this.color = color;
		this.unidade = unidade;
	}

	@Override
	public final String getNome() {
		return nome;
	}

	// Métodos final não podem ser sobrescritos, ou seja, não admitem uma nova implementação.
	public final FormaGeometrica setNome(String nome) {
		this.nome = nome;
		return this;
	}

	public final Color getColor() {
		return color;
	}

	public final FormaGeometrica setColor(Color color) {
		this.color = color;
		return this;
	}

	public final String getUnidade() {
		return unidade;
	}

	public final FormaGeometrica setUnidade(String unidade) {
		this.unidade = unidade;
		return this;
	}

	@Override
	public String toString() {
		// Chamada explícita ao método toString da superclasse Forma.
		return String.format("%s: FormaGeometrica", super.toString());
	}

	/**
	 * Obtém a unidade usada pela forma geométrica para representar o valor de sua área.
	 */
	public String obterUnidadeArea() {
		return obterUnidadeArea(this);
	}

	/**
	 * Obtém a unidade usada pela forma geométrica para representar o valor de sua área.
	 */
	public static String obterUnidadeArea(FormaGeometrica formaGeometrica) {
		return formaGeometrica.getUnidade().equals(Forma.CENTIMETRO) ? 
																			   Forma.CENTIMETRO_QUADRADO : Forma.METRO_QUADRADO;
	}
} // class FormaGeometrica 
