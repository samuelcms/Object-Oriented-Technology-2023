package too.heranca.formageometrica;

import java.awt.Color;

public class Forma2D extends FormaGeometrica {

	public Forma2D() {
		// Chamada explícita ao construtor default da superclasse FormaGeometrica.
		super();
		
		/* Acessa diretamente um atributo da superclasse FormaGeometrica na subclasse Forma2D porque ele possui
		 * acesso protegido.
		 */
		nome = "Forma 2D";
	}

	public Forma2D(String nome, Color color) {
		// Chamada explícita ao construtor FormaGeometrica(String, Color)  da superclasse FormaGeometrica.
		super(nome, color);
	}

	public Forma2D(String nome, Color color, String unidade) {
		// Chamada explícita ao construtor FormaGeometrica(String, Color, String) da superclasse FormaGeometrica.
		super(nome, color, unidade);
	}

	@Override
	public String toString() {
		// Chamada explícita ao método toString da superclasse FormaGeometrica.
		return String.format("%s: Forma2D", super.toString());
	}
} // class Forma2D 
