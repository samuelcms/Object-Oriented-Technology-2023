package too.heranca.formageometrica;

import java.awt.Color;

public final class Triangulo extends Forma2D {
	private float base, altura;
	
	public Triangulo() {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super("Triângulo", Color.BLUE);
	}

	public Triangulo(String nome, Color color) {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super(nome, color);
	}

	public Triangulo(String nome, Color color, String unidade) {
		// Chamada explícita ao construtor Forma2D(String, Color, String) da superclasse Forma2D.
		super(nome, color, unidade);
	}

	public Triangulo(float base, float altura) {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super("Triângulo", Color.BLUE);

		setBase(base);
		setAltura(altura);
	}

	public Triangulo(String nome, Color color, float base, float altura) {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super(nome, color);
		
		setBase(base);
		setAltura(altura);
	}

	public Triangulo(String nome, Color color, String unidade, float base, float altura) {
		// Chamada explícita ao construtor Forma2D(String, Color, String) da superclasse Forma2D.
		super(nome, color, unidade);
		
		setBase(base);
		setAltura(altura);
	}

	public float getBase() {
		return base;
	}

	/**
	 * Define a base se for positiva, caso contrário, a base não será alterada.
	 */
	public Triangulo setBase(float base) {
		if (base > 0 )
			this.base = base;
		
		return this;
	}

	public float getAltura() {
		return altura;
	}

	/**
	 * Define a altura se for positiva, caso contrário, a altura não será alterada.
	 */
	public Triangulo setAltura(float altura) {
		if (altura > 0)
			this.altura = altura;
		
		return this;
	}
	
	@Override
	public String toString() {
		// Chamada explícita ao método toString da superclasse Forma2D.
		return String.format("%s: %s - Base: %,1.2f %5$s ; Altura: %4$,1.2f %5$s", super.toString(), nome, base, altura, 
				                              unidade);
	}

	@Override
	public double area() {
		return base * altura / 2; 
	}
} // class Triangulo 
