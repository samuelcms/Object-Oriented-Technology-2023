package too.heranca.formageometrica;

import java.awt.Color;

public class Forma3D extends FormaGeometrica {

	public Forma3D() {
		// Chamada implícita ao construtor default da superclasse FormaGeometrica.
		
		/* Acessa diretamente um atributo da superclasse FormaGeometrica na subclasse Forma2D porque ele possui
		 * acesso protegido.
		 */
		nome = "Forma 3D";
	}

	public Forma3D(String nome, Color color) {
		// Chamada explícita ao construtor FormaGeometrica(String, Color) da superclasse FormaGeometrica.
		super(nome, color);
	}

	public Forma3D(String nome, Color color, String unidade) {
		// Chamada explícita ao construtor FormaGeometrica(String, Color, String) da superclasse FormaGeometrica.
		super(nome, color, unidade);
	}

	@Override
	public String toString() {
		// Chamada explícita ao método toString da superclasse FormaGeometrica.
		return String.format("%s: Forma3D", super.toString());
	}
} // class Forma3D 
