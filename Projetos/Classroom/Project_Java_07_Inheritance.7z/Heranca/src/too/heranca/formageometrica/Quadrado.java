package too.heranca.formageometrica;

import java.awt.Color;

/**
 * As classes final não podem ser especializadas, ou seja, não admite subclasse. 
 */
public final class Quadrado extends Forma2D {
	private float lado;
	
	public Quadrado() {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super("Quadrado", Color.GREEN);
	}

	public Quadrado(String nome, Color color) {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super(nome, color);
	}

	public Quadrado(String nome, Color color, String unidade) {
		// Chamada explícita ao construtor Forma2D(String, Color, String) da superclasse Forma2D.
		super(nome, color, unidade);
	}

	public Quadrado(float lado) {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super("Quadrado", Color.GREEN);
		
		setLado(lado);
	}

	public Quadrado(String nome, Color color, float lado) {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super(nome, color);

		setLado(lado);
	}

	public Quadrado(String nome, Color color, String unidade, float lado) {
		// Chamada explícita ao construtor Forma2D(String, Color, String) da superclasse Forma2D.
		super(nome, color, unidade);
		
		setLado(lado);
	}

	public float getLado() {
		return lado;
	}

	/**
	 * Define o lado se for positivo, caso contrário, o lado não será alterado.
	 */
	public Quadrado setLado(float lado) {
		if (lado > 0)
			this.lado = lado;
		
		return this;
	}

	@Override
	public String toString() {
		// Chamada explícita ao método toString da superclasse Forma2D.
		return String.format("%s: %s - Lado: %,1.2f %s", super.toString(), nome, lado, unidade);
	}

	@Override
	public double area() {
		return lado * lado;
	}
} // class Quadrado 
