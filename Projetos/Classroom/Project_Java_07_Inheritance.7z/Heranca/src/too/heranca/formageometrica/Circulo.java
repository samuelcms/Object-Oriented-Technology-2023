package too.heranca.formageometrica;

import java.awt.Color;

public final class Circulo extends Forma2D {
	private float raio;
	
	public Circulo() {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super("Círculo", Color.RED);
	}

	public Circulo(String nome, Color color) {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super(nome, color);
	}

	public Circulo(String nome, Color color, String unidade) {
		// Chamada explícita ao construtor Forma2D(String, Color, String) da superclasse Forma2D.
		super(nome, color, unidade);
	}

	public Circulo(float raio) {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super("Círculo", Color.RED);
		
		setRaio(raio);
	}

	public Circulo(String nome, Color color, float raio) {
		// Chamada explícita ao construtor Forma2D(String, Color) da superclasse Forma2D.
		super(nome, color);
		
		setRaio(raio);
	}

	public Circulo(String nome, Color color, String unidade, float raio) {
		// Chamada explícita ao construtor Forma2D(String, Color, String) da superclasse Forma2D.
		super(nome, color, unidade);
		
		setRaio(raio);
	}

	public float getRaio() {
		return raio;
	}

	/**
	 * Define o raio se for positivo, caso contrário, o lado não será alterado.
	 */
	public Circulo setRaio(float raio) {
		if (raio > 0 )
			this.raio = raio;
		
		return this;
	}

	@Override
	public String toString() {
		// Chamada explícita ao método toString da superclasse Forma2D.
		return String.format("%s: %s - Raio: %,1.2f %s", super.toString(), nome, raio, unidade);
	}

	@Override
	public double area() {
		return Math.PI * Math.pow(raio, 2); 
	}
} // class Circulo 