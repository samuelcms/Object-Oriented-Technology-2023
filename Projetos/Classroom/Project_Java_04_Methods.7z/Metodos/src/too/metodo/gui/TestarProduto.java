package too.metodo.gui;

import static too.metodo.gui.EntradaSaida.*;

import too.metodo.Produto;

public class TestarProduto {

	public static void main(String[] args) {
		testarProduto();
	}

	public static void testarProduto() {
		var quantidadeProdutos = formatar(String.format("Quantidade de produtos: %d", Produto.getQuantidadeProduto()));
		
		Produto hamburguer = new Produto(), arroz = new Produto("Arroz", 2, 27), feijao = new Produto("Feijão", 5, 9);
		
		hamburguer.setNome("McFeliz");
		hamburguer.setPreco(12);
		hamburguer.setQuantidade(3);
		
		/* Solução 1: usa o método formatar(String) da classe EntradaSaida.
		    
			formatar(LINHA_VAZIA);
			formatar(hamburguer.toString());
			formatar(NOVA_LINHA);
			formatar(arroz.toString());
			formatar(NOVA_LINHA);	
			formatar(obterProduto(feijao));
			formatar(NOVA_LINHA);
		
			StringBuilder stringBuilder = formatar(String.format("\nQuantidade de produtos: %d", 
				                                                                 Produto.getQuantidadeProduto()));
		*/
		
		/* Solução 2: usa o método formatar(String...) da classe EntradaSaida. 
		 * 					O uso da lista de argumentos de comprimento variável do tipo String nesta solução é mais
		 * 					flexível, porque permite que esse método formatar receba uma lista de valores do tipo String
		 *                     ou um vetor do mesmo tipo (veja o exemplo abaixo).
		 *                       
		 * 		String vogais[] = {"a", "e", "i", "o", "u"};
		 * 
		 *  		formatar("a", "e", "i", "o", "u");
		 *  		formatar(vogais);
		 */
		StringBuilder stringBuilder = formatar(quantidadeProdutos.toString(), LINHA_VAZIA, hamburguer.toString(), 
				                                                             NOVA_LINHA, arroz.toString(), NOVA_LINHA, obterProduto(feijao), 
				                                                             NOVA_LINHA, String.format("\nQuantidade de produtos: %d", 
				                                                             Produto.getQuantidadeProduto()));
		
		msgInfo(stringBuilder.toString(), "Testar Produto");
		
		System.exit(0);
	} // testarProduto()
	
	/**
	 * Obtém uma representação string com os dados do produto.
	 */
	public static String obterProduto(Produto produto) {
		return String.format("%03d. Nome: %s , Quantidade: %,d , Preço: R$ %,1.2f", produto.CODIGO, produto.getNome(), 
				                              produto.getQuantidade(),produto.getPreco());
	}
} // class TestarProduto