package too.metodo.gui;

import javax.swing.JOptionPane;

public class EntradaSaida {
	private static StringBuilder stringBuilder = new StringBuilder();
	public static final String NOVA_LINHA = "\n";
	public static final String LINHA_VAZIA = "\n\n";
	
	/**
	 * Exibe uma mensagem informativa em uma caixa de diálogo com título.
	 * 
	 * @param mensagem texto a ser exibido na caixa de diálogo;
	 * @param titulo texto a ser exibido na barra de título da caixa de diálogo.
	 */
	public static void msgInfo(String mensagem, String titulo) {
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.INFORMATION_MESSAGE);		
	}

	/**
	 * Exibe uma mensagem de erro em uma caixa de diálogo com título.
	 * 
	 * @param mensagem texto a ser exibido na caixa de diálogo;
	 * @param titulo texto a ser exibido na barra de título da caixa de diálogo.
	 */
	public static void msgErro(String mensagem, String titulo) {
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.ERROR_MESSAGE);		
	}

	/**
	 * Exibe uma mensagem de alerta em uma caixa de diálogo com título.
	 * 
	 * @param mensagem texto a ser exibido na caixa de diálogo;
	 * @param titulo texto a ser exibido na barra de título da caixa de diálogo.
	 */
	public static void msgAlerta(String mensagem, String titulo) {
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.WARNING_MESSAGE);
	}

	/**
	 * Lê uma string em uma caixa de diálogo com título.
	 * 
	 * @param mensagem texto a ser exibido na caixa de diálogo;
	 * @param titulo texto a ser exibido na barra de título da caixa de diálogo.
	 * 
	 * @return a <code>String</code> fornecida pelo usuário ou <code>null</code> quando usuário cancelar a operação,
	 * ou seja, ele clicar no botão Cancelar ou Fechar da caixa de diálogo ou teclar ESC.
	 * 
	 * @see javax.swing.JOptionPane
	 */
	public static String readString(String mensagem, String titulo) {
		return JOptionPane.showInputDialog(null, mensagem, titulo, JOptionPane.QUESTION_MESSAGE);
	}
	
	/**
	 * Lê um número inteiro em uma caixa de diálogo com título.
	 * 
	 * @param mensagem texto a ser exibido na caixa de diálogo.
	 * @param titulo texto a ser exibido na barra de título da caixa de diálogo.
	 * 
	 * @return um número fornecido pelo usuário ou <code>null</code> quando usuário cancelar a operação,
	 * ou seja, ele clicar no botão Cancelar ou Fechar da caixa de diálogo ou teclar ESC.
	 */
	public static Integer lerNumeroInteiro(String mensagem, String titulo) {
		String string = readString(mensagem, titulo);
		
		return (string != null) ? Integer.parseInt(string) : null;
	}
	
	/**
	 * Lê um número real em uma caixa de diálogo com título.
	 * 
	 * @param mensagem texto a ser exibido na caixa de diálogo.
	 * @param titulo texto a ser exibido na barra de título da caixa de diálogo.
	 * 
	 * @return um número fornecido pelo usuário ou <code>null</code> quando usuário cancelar a operação,
	 * ou seja, ele clicar no botão Cancelar ou Fechar da caixa de diálogo ou teclar ESC.
	 */
	public static Double lerNumeroReal(String mensagem, String titulo) {
		String string = readString(mensagem, titulo);
		
		return (string != null) ? Double.parseDouble(string) : null;
	}
	
	/**
	 * Cria e retorna uma <i>string</i> formatada com os argumentos string que a ela são adicionados. 
	 * Portanto, a formatação é definida pela sequência que esses argumentos são adicionados.
	 * A cada chamada ao método formatar as <i>strings</i> passadas como argumentos são adicionadas
	 * na <code>String</code> formatada, portanto para reiniciar uma nova formatação o usuário deverá,
	 * por exemplo, usar o comando setLength da classe StringBuilder.
	 * 
	 * <pre><b>Exemplo:</b> 
	 * 	formatar("Salário: R$");
	 * 	StringBuilder stringBuilder = formatar(Float.toString(funcionario.getSalario()));
	 * 
	 * 	// Exibirá a saída: "Salário: R$ 1222", considerando que getSalario() retornou 1222.
	 * 	System.out.println(stringBuilder); 
	 * 
	 * 	stringBuilder.setLength(0);
	 * 
	 * 	// Exibirá a saída: "" 
	 * 	System.out.println(stringBuilder);
	 * </pre>
	 * 
	 *  @param string conteúdo a ser adicionado na <code>String</code> formatada.
	 *  
	 *  @return um <code>StringBuilder</code> com a <i>string</i> formatada.
	 */
	public static StringBuilder formatar(String string) {
		return stringBuilder.append(string);
	}
	
	/**
	 * Cria e retorna uma <i>string</i> formatada usando os argumentos do vetor de <i>strings</i> para 
	 * adicioná-los a <i>string</i> formatada. Portanto, a formatação é definida pela sequência que esses 
	 * argumentos são adicionados. A cada chamada ao método formatar uma nova <i>string</i> formatada
	 * será criada. 
	 * 
	 * @param strings 
	 * 
	 * @return um <code>StringBuilder</code> com a <i>string</i> formatada.
	 */
	public static StringBuilder formatar(String... strings) {
		var stringBuilder = new StringBuilder();
		
		// Solução 1: Adiciona as strings do vetor no StringBuilder.
		for (int indice = 0; indice < strings.length ; indice++)
			stringBuilder.append(strings[indice]);
		
		return stringBuilder;
	}
} // class EntradaSaida