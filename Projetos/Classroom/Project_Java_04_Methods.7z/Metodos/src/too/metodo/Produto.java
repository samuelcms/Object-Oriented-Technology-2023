package too.metodo;

public class Produto {
	// Variáveis de instância.
	private String nome;
	private int quantidade;
	private float preco;
	public final int CODIGO; 
	
	// Variáveis de classe (estáticas).
	private static int gerarCodigo,               // Usada para gerar um código único para cada produto. 
	                    		   quantidadeProduto;  // Contabiliza o número de objetos da classe Produto que serão criados.
	
	/**
	 * Construtor default ou padrão.
	 */
	public Produto() {
		nome = "";
		CODIGO = ++gerarCodigo;
		quantidadeProduto++;
	}

	/**
	 * Construtor sobrecarregado.
	 */
	public Produto(String nome, int quantidade, float preco) {
		// Chamada explícita ao construtor default da classe Produto.
		this(); 
		
		this.nome = nome;
		this.quantidade = quantidade;
		this.preco = preco;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public float getPreco() {
		return preco;
	}

	public void setPreco(float preco) {
		this.preco = preco;
	}

	/**
	 * Obtém a quantidade de objetos da classe Produto que foram criados.
	 */
	public static int getQuantidadeProduto() {
		/*
				preco = 10; // ERRO: não se pode acessar um atributo (variável de instância) do objeto em um método estático.
		*/
		return quantidadeProduto;
	}

	@Override
	public String toString() {
		return String.format("%03d. Produto: %s, Quantidade: %,d, R$ %,1.2f", CODIGO, nome, quantidade, preco);
	}
} // class Produto