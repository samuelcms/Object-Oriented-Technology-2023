package too.classeeobjeto2;

import java.util.ArrayList;
import java.util.List;

public class Cliente {
	private String nome, cpf;
	
	/*
	 * O relacionamento entre as classes Cliente (Todo) e Contato (Parte) é um exemplo de composição de objetos.
	 * A lista abaixo representa a relação de contatos do cliente.
	 */
	private List<Contato> contatoList;

	public Cliente() {
		contatoList = new ArrayList<Contato>();
	}

	public Cliente(String nome, String cpf) {
		this();
		this.nome = nome;
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	@Override
	public String toString() {
		StringBuilder stringBuilder = new StringBuilder(String.format("Cliente: %s, CPF: %s\n", nome, cpf));
		
		for (Contato contato : contatoList) {
			stringBuilder.append(contato.toString());
			stringBuilder.append("\n");
		}
		return stringBuilder.toString();
	}

	/**
	 * Obtém todos os valores do contato associado com o mesmo tipo de contato. Por exemplo, se o tipo do contato 
	 * for e-mail obtém todos os e-mails do contato. 
	 */
	public List<String> obterValorContato(TipoContato tipoContato) {
		List<String> valoresList = new ArrayList<>();
		
		for (Contato contato : contatoList)
			if (tipoContato == contato.getTipo())
				valoresList.add(contato.getValor());
		
		return valoresList;
	}

	/**
	 * Define o tipo (p. ex., e-mail, telefone) e o valor do contato (p. ex., ni@ifsudestemg.edu.br, (32) 3693-8616).
	 */
	public void definirContato(TipoContato tipoContato, String valor) {
		contatoList.add(new Contato(tipoContato, valor));
	}
	
	/**
	 * Atualiza o valor atual (p. ex., ni@ifsudestemg.edu.br) de um tipo de contato (p. ex., e-mail) com um novo valor.
	 */
	public void atualizarValorContato(TipoContato tipoContato, String valorAtual, String valorNovo) {
		for (Contato contato : contatoList)
			if (tipoContato == contato.getTipo() && valorAtual.equalsIgnoreCase(contato.getValor()))
				contato.setValor(valorNovo);
	}
} // class Cliente

/**
 * Esta classe possui o acesso default do Java, ou seja, o acesso de pacote.
 * O objetivo dessa classe é representa as diversas formas de contato de uma pessoa física ou jurídica.
 */
class Contato {
	// Identifica o tipo do contato, p. ex., e-mail, telefone, endereço.
	private TipoContato tipo; 
	
	// Informa o valor associado ao tipo do contato, p. ex., ni@ifsudestemg.edu.br, (32) 3693-8616, BQ.
	private String valor;

	public Contato() {
	}

	public Contato(TipoContato tipo, String valor) {
		this.tipo = tipo;
		this.valor = valor;
	}

	public TipoContato getTipo() {
		return tipo;
	}

	public void setTipo(TipoContato tipo) {
		this.tipo = tipo; 
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}

	@Override
	public String toString() {
		return String.format("%s: %s", tipo.getTipo(), valor); 
	}
} // class Contato
