package too.classeeobjeto2;

public enum TipoContato {
	E_MAIL("E-mail"),
	TELEFONE_MOVEL("Telefone Móvel"),
	TELEFONE_FIXO("Telefone Fixo"),
	ENDERECO("Endereço");
	
	private String tipo;

	private TipoContato(String tipo) {
		this.tipo = tipo;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public String toString() {
		return getTipo();
	}
} // enum TipoContato
