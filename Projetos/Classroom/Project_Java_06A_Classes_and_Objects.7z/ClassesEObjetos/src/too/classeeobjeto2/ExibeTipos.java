package too.classeeobjeto2;

import java.util.List;

public class ExibeTipos {

	public static void main(String[] args) {
		exibeTipos();
	}
	
	/**
	 * Exibe no console os nomes dos tipos de dados primitivos e por referência.
	 */
	public static void exibeTipos() {
		System.out.println(int.class);
		System.out.println(boolean.class);
		
		// A forma estática de obter os nomes dos tipos por referência (interface ou classe).
		System.out.println(List.class.getCanonicalName());
		System.out.println(ContaCorrente.class.getName());
		System.out.println(ContaCorrente.class.getCanonicalName());
		System.out.println(ContaCorrente.class.getSimpleName());
	}
} // class ExibeTipos
