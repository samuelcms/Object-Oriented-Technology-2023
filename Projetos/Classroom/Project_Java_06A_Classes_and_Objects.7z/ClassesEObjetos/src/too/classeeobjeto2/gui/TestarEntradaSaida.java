package too.classeeobjeto2.gui;

import static javax.swing.SwingConstants.*;
import static javax.swing.JOptionPane.*;
import static too.classeeobjeto2.gui.EntradaSaida.*;

public class TestarEntradaSaida {

	public static void main(String[] args) {
		testarEntradaSaida();
	}

	public static void testarEntradaSaida() {
		String[] comandosMenu = new String[] {"Cadastrar", "Consultar"};
		
		menu("Escolha uma opção abaixo.", "Controle de Estoque", comandosMenu, comandosMenu[0]);
		
		msgInfo("Tá com pressa de volta ao normal?\nPense que parte desse normal você quer que volte. ", "Reflexão");
		msgErro("Não foi possível ler o arquivo.", "Editor de Texto");
		
		int resposta = msgConfirma("Deseja excluir o arquivo?", "Gerenciador de Arquivos");
		msgInfo((resposta == YES_OPTION) ? "Arquivo excluído com sucesso." : "Operação cancelada.", "Gerenciador de Arquivos");
		
		String texto = "Provides classes that are fundamental to the design of the Java programming language. " +
				                  "The most important classes are Object, which is the root of the class hierarchy, and Class, instances of which represent classes at run time. ";

		exibirTexto(texto, "Pacote java.lang", 7, 20);
		exibirTexto(texto, "Pacote java.lang", 4, 40);
		
		// Define os dados a serem exibidos na tabela. O recurso autoboxing é usado na inicialização abaixo.
		Object dadosTabela[][] = {{1, "Lógica de Programação", 9.5}, 
		                                           {2, "Banco de Dados", 8.5},
		                                           {3, "Análise de Sistemas", 10},
		                                           {4, "Estrutura de Dados I", 7.5}};
		
		// Define os nomes das colunas da tabela.
		String colunasTabela[] = {"Código", "Disciplina", "Nota"};
		
		// Define a largura e o alinhamento das colunas da tabela.
		int larguraColuna[] = {50, 200, 50}, alinhamentoColuna[] = {CENTER, LEFT, CENTER};
		
		lerNumeroInteiro("Código:", "Cadastrar Produto");
		readString("Nome:", "Cadastrar Produto");
		lerNumeroReal("Preço:", "Cadastrar Produto");
		
		exibirTabela("Disciplinas", dadosTabela, colunasTabela, larguraColuna, alinhamentoColuna, 300, 64);
		exibirTabela("Disciplinas", dadosTabela, colunasTabela, larguraColuna, null, 300, 64);
		
		System.exit(0);
	} // testarEntradaSaida()
} // class TestarEntradaSaida