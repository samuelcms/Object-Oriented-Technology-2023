package too.classeeobjeto2.gui;

import too.classeeobjeto2.Cliente;
import too.classeeobjeto2.ContaCorrente;
import too.classeeobjeto2.TipoContato;


import static too.classeeobjeto2.gui.EntradaSaida.*;

import javax.swing.JScrollPane;

public class TestarContaCorrente {

	public static void main(String[] args) {
		testarContaCorrente(); 
	}

	public static void testarContaCorrente() {
		// Cria um objeto Cliente.
		Cliente anaBeatriz = new Cliente("Ana Beatriz", "123.456.789-45");
		
		// Utiliza o objeto Cliente para criar duas contas para ele.
		ContaCorrente contaCorrente = new ContaCorrente(anaBeatriz, 500),
						     		contaInvestimento = new ContaCorrente(anaBeatriz, 850);
			
		// Define os tipos de contato do cliente.
		anaBeatriz.definirContato(TipoContato.E_MAIL, "anabeatriz@gmail.com");
		anaBeatriz.definirContato(TipoContato.E_MAIL, "anabeatriz@ifsudestemg.edu.br");
		anaBeatriz.definirContato(TipoContato.ENDERECO, "Barbacena-MG");
		
		// Exibe os atributos do objeto Cliente.
		writeTextArea(anaBeatriz.toString());
		
		// Atualiza o endereço do cliente.
		anaBeatriz.atualizarValorContato(TipoContato.ENDERECO, "Barbacena-MG", "R. Quinze de Novembro, 15, Centro, Barbacena-MG");
		
		// Exibe os atributos do objeto ContaCorrente.
		writeTextArea(NOVA_LINHA);
		writeTextArea(contaCorrente.toString());
		writeTextArea(LINHA_VAZIA);
		
		// Exibe os e-mails do cliente.
		writeTextArea(String.format("E-mails de %s: %s", anaBeatriz.getNome(), 
				                                            anaBeatriz.obterValorContato(TipoContato.E_MAIL)));
		
		// Exibe o o número e o saldo das contas corrente e de investimento.
		writeTextArea(LINHA_VAZIA);
		writeTextArea(String.format("Nº Conta Investimento: %d, Saldo: R$ %,1.2f", contaInvestimento.getNumero(), contaInvestimento.saldo()));
		writeTextArea(String.format("\nNº Conta Corrente: %d, Saldo: R$ %,1.2f",  contaCorrente.getNumero(), contaCorrente.saldo()));

		// Realiza um depósito na conta corrente.
		writeTextArea(String.format("\n\nRealizando um depósito de R$ 300,00 na conta corrente..."));
		contaCorrente.deposito(300);

		// Realiza um saque na conta investimento.
		writeTextArea(String.format("\n\nRealizando um saque de R$ 150,00 na conta investimento..."));
		contaInvestimento.saque(150);

		// Exibe o saldo atualizado das contas.
		writeTextArea(String.format("\n\nO saldo atual da conta corrente Nº %d de propriedade de %s é R$ %,1.2f.", contaCorrente.getNumero(), contaCorrente.getCliente().getNome(), contaCorrente.saldo()));
		writeTextArea(String.format("\n\nO saldo atual da conta investimento Nº %d de propriedade de %s é R$ %,1.2f.", contaInvestimento.getNumero(), contaInvestimento.getCliente().getNome(), contaInvestimento.saldo()));

		// Realiza um saque na conta investimento.
		writeTextArea(String.format("\n\nTentativa de realizar um saque de R$ 1.500,00 na conta investimento..."));
		contaInvestimento.saque(1500);
		
		// Exibe o saldo da conta investimento.
		writeTextArea(String.format("\n\nO saldo atual da conta investimento Nº %d de propriedade de %s é R$ %,1.2f.", contaInvestimento.getNumero(), contaInvestimento.getCliente().getNome(), contaInvestimento.saldo()));
		
		// Exibe a saída do programa.
		msgInfo(new JScrollPane(getTextArea()), "Teste da Classe ContaCorrente");
		
		// Marca os objetos abaixo para remoção.
		contaCorrente = contaInvestimento = null;
		anaBeatriz = null; 
		
		// Chama explicitamente o coletor de lixo do Java.
		System.gc();
		
		// Finaliza o programa.
		System.exit(0);
	} // testarContaCorrente()
} // class TestarContaCorrente 