package too.classeeobjeto2;

public class ContaCorrente {
	private int numero;
	private double valor;
	
	// O relacionamento entre as classes ContaCorrente (Todo) e Cliente (Parte) é um exemplo de agregação de objetos.
	private Cliente cliente;
	
	private static int geraNumeroConta, quantidadeContaCorrente;
	
	public ContaCorrente() {
		// Chamada explícita ao construtor sobrecarregado.
		this(new Cliente(), 0);
	}

	/**
	 * Cria uma conta corrente com titular e valor inicial especificados. Esse valor corresponde ao depósito inicial
	 * na conta do titular.  
	 */
	public ContaCorrente(Cliente cliente, double valor) {
		setCliente(cliente);
		deposito(valor);
		
		numero = ++geraNumeroConta;
		quantidadeContaCorrente++;
	}

	public Cliente getCliente() {
		return cliente;
	}

	/**
	 * Define o cliente da conta corrente se a referência for válida e retorna true, caso contrário, ou seja, se for null,
	 * não altera e retorna false.
	 */
	public boolean setCliente(Cliente cliente) {
		if (cliente != null) {
			this.cliente = cliente;
			return true;
		}
		return false;
	}

	public int getNumero() {
		return numero;
	}

	public static int getQuantidadeContaCorrente() {
		return quantidadeContaCorrente;
	}

	@Override
	public String toString() {
		// A forma não estática de obter o nome do tipo por referência (classe ContaBancaria).
		return String.format("%s - Nº: %,d, %sValor: R$ %1.2f", getClass().getSimpleName(), numero, cliente, valor);
	}
	
	/**
	 * Obtém o valor atual da conta corrente.
	 */
	public double saldo() {
		return valor;
	}
	
	/**
	 * Permite depositar ou acrescentar um valor na conta corrente.
	 * Retorna <code>true</code> se a operação foi realizada ou <code>false</code> se o valor fornecido é inválido,
	 * ou seja, é negativo.
	 */
	public boolean deposito(double valor) {
		if (valor >= 0) {
			this.valor += valor;
			return true;
		}
		return false;
	}
	
	/**
	 * Permite retirar um valor da conta corrente.
	 * Retorna <code>true</code> se a operação foi realizada ou <code>false</code> se o valor solicitado na operação
	 * é inválido, ou seja, o saldo disponível na conta é insuficiente para fazer a retirada.
	 */
	public boolean saque(double valor) {
		if (valor > 0 && saldo() >= valor) {
			this.valor -= valor;
			return true;
		}
		return false;
	}
} // class ContaCorrente