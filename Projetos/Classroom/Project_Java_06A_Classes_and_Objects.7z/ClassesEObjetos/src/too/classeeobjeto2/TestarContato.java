package too.classeeobjeto2;

public class TestarContato {

	public static void main(String[] args) {
		testarContato();
	}

	public static void testarContato() {
		Contato contato = new Contato();
		
		/*  TipoContato tipoContato = new TipoContato(); // ERRO: não se pode instanciar uma enumeração.  
		  
		    Os comandos abaixo são válidos se os atributos do objeto da classe Contato possuem o acesso de pacote.
		     
				contato.tipo = TipoContato.ENDERECO;
				contato.valor = "R. Monsenhor José Augusto";
		*/
		contato.setTipo(TipoContato.ENDERECO);
		contato.setValor("R. Monsenhor José Augusto");
		
		TipoContato eMail = TipoContato.E_MAIL,
				                celular = TipoContato.TELEFONE_MOVEL;
		
		System.out.println(eMail);
		System.out.println(celular.toString());
		System.out.println(eMail.getTipo());
		System.out.printf("%s: %s\n", contato.getTipo(), contato.getValor());
		System.out.println(contato);
	}
} // class TestarContato