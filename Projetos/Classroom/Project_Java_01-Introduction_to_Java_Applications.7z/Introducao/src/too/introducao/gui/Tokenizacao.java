package too.introducao.gui;

import java.util.StringTokenizer;

public class Tokenizacao {

	public static void main(String[] args) {
		tokenizacao();
	}

	public static void tokenizacao() {
		final String SEPARADORES = " :,;.?!";
		String string = EntradaSaida.readString("Frase:", "Tokenização de Strings");
		
		// Verifica se o usuário cancelou a operação de leitura.
		if (string != null) {
			StringTokenizer stringTokenizer = new StringTokenizer(string, SEPARADORES);
			String resultado = String.format("A string possui %d tokens, que são:\n\n", stringTokenizer.countTokens());
			
			 while (stringTokenizer.hasMoreTokens()) 
				resultado += stringTokenizer.nextToken().concat("\n");
			 
			 EntradaSaida.msgInfo(resultado, "Tokenização de Strings");
		}
		else
			EntradaSaida.msgAlerta("Você cancelou a operação, então o programa será finalizado.", "Tokenização de Strings");
		
		System.exit(0);
	} // tokenizacao()
} // class Tokenizacao