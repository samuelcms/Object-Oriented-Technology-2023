package too.introducao.gui;

import javax.swing.JOptionPane;

public class OlaMundo {

	public static void main(String[] args) {
		olaMundo();
	}

	private static void olaMundo() {
		JOptionPane.showMessageDialog(null, "Bem-vindo a programação GUI com Java.", "Saudação", 
				        												JOptionPane.INFORMATION_MESSAGE);
		
		// Finaliza a máquina virtual do Java (JVM).
		System.exit(0);
	}
}
