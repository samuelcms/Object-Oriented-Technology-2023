package too.introducao.gui;

import javax.swing.JOptionPane;

public class StringMutavelEImutavel {

	public static void main(String[] args) {
		stringMutavelEImutavel();
	}
	
	public static void stringMutavelEImutavel() {
		stringImutavel();
		stringMutavel();
		
		// Finaliza imediatamente o programa Java GUI.
		System.exit(0);
	}
	
	/**
	 * Apresenta a classe StringBuilder.
	 */
	public static void stringMutavel() {
		StringBuilder stringBuilder = new StringBuilder("As letras do alfabeto são: ");
		final char ESPACO = ' ';
		
		/* Usar uma string modificável como StringBuilder ou StringBuffer evita no código abaixo que 52 objetos do tipo
		 * String sejam criados toda vez que um caractere for adicionado na string.
		 */
		for (char letra = 'A'; letra <= 'Z'; letra++) {
			stringBuilder.append(letra);
			stringBuilder.append(ESPACO);
		}
		
		msgInfo(stringBuilder.toString(), "String Mutável");
	}
	
	/**
	 * Reforça o conceito de que objetos da classe String são constantes e não podem ser modificados.
	 */
	public static void stringImutavel() {
		String string = "Esta string é imutável!", string2 = new String("Esta string é imutável!");
		
		String resultado = "string = " + string;
		
		/* A atribuição abaixo não modifica o objeto String, ela altera a referência da variável string para o novo objeto
		 * anônimo do tipo String, que é a string vazia.  */
		string = "";
		
		resultado += "\nstring = ";

		// Objetos anônimos do tipo String que são idênticos possuem a mesma referência.
		string = "Esta string é imutável!";
		
		if (string == "Esta string é imutável!")
			resultado += "\n\nAs strings são iguais.";
		else
			resultado += "\n\nAs strings são diferentes.";
		
		if (string == string2)
			resultado += "\nstring == string2\n\nAs strings são iguais.";
		else
			resultado += "\nstring == string2\n\nAs strings são diferentes.";

		if (string == string2.intern())
			resultado += "\nstring == string2.intern()\n\nAs strings são iguais.";
		else
			resultado += "\nstring == string2.intern()\n\nAs strings são diferentes.";

		if (string.equals(string2))
			resultado += "\nstring.equals(string2)\n\nAs strings são iguais.";
		else
			resultado += "\nstring.equals(string2)\n\nAs strings são diferentes.";
		
		if ("oi".equals("OI"))
			resultado += "\n\"oi\".equals(\"OI\")\n\nAs strings são iguais.";
		else
			resultado += "\n\"oi\".equals(\"OI\")\n\nAs strings são diferentes.";
		
		if ("oi".equalsIgnoreCase("OI"))
			resultado += "\n\"oi\".equalsIgnoreCase(\"OI\")\n\nAs strings são iguais.";
		else
			resultado += "\n\"oi\".equalsIgnoreCase(\"OI\")\n\nAs strings são diferentes.";
		
		msgInfo(resultado, "String Imutável");
	} // stringImutavel()

	/**
	 * Exibe uma mensagem informativa em uma caixa de diálogo com título.
	 */
	public static void msgInfo(String mensagem, String titulo) {
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.INFORMATION_MESSAGE);
	}
} // class StringMutavelEImutavel
