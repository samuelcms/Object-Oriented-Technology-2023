package too.introducao.gui;

import javax.swing.JOptionPane;

public class EntradaSaida {
	/**
	 * Exibe uma mensagem informativa em uma caixa de diálogo com título.
	 */
	public static void msgInfo(String mensagem, String titulo) {
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.INFORMATION_MESSAGE);		
	}

	/**
	 * Exibe uma mensagem de erro em uma caixa de diálogo com título.
	 */
	public static void msgErro(String mensagem, String titulo) {
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.ERROR_MESSAGE);		
	}

	/**
	 * Exibe uma mensagem de alerta em uma caixa de diálogo com título.
	 */
	public static void msgAlerta(String mensagem, String titulo) {
		JOptionPane.showMessageDialog(null, mensagem, titulo, JOptionPane.WARNING_MESSAGE);
	}

	/**
	 * Lê uma string em uma caixa de diálogo.
	 * 
	 * @param mensagem texto a ser exibido na caixa de diálogo.
	 * @param titulo texto a ser exibido na barra de título da caixa de diálogo.
	 * 
	 * @return a <code>String</code> fornecida pelo usuário ou <code>null</code> quando usuário cancelar a operação,
	 * ou seja, ele clicar no botão Cancelar ou Fechar da caixa de diálogo ou teclar ESC.
	 * 
	 * @see javax.swing.JOptionPane
	 */
	public static String readString(String mensagem, String titulo) {
		return JOptionPane.showInputDialog(null, mensagem, titulo, JOptionPane.QUESTION_MESSAGE);
	}
} // class EntradaSaida