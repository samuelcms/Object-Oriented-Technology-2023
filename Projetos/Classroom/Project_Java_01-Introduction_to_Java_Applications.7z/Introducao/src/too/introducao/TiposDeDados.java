package too.introducao;

public class TiposDeDados {

	public static void main(String[] args) {
		tiposDeDados();
	}

	public static void tiposDeDados() {
		tiposPrimitivos();
		
		tiposPorReferencia();
	}
	
	public static void tiposPrimitivos() {
		int numero = Integer.MIN_VALUE;
		byte idade = Byte.MAX_VALUE;
		final float PI = 3.141592F;
		final boolean VERDADEIRO = true;
		final double NEPER = Math.E;

		System.out.println("- Tipos Primitivos");
		System.out.println("\n\tverdadeiro: " + VERDADEIRO);
		System.out.printf("\tnúmero: %,d\n", numero);
		System.out.printf("\tidade: %d\n\tpi: %1.6f\n\te: %1.15f\n", idade, PI, NEPER);
		
		System.out.printf("\tsqrt(e): %1.15f\n", Math.sqrt(NEPER));
	}

	public static void tiposPorReferencia() {
		// Cria e inicializa as referências com os objetos da classe String.
		String frase = "Hoje o laboratório estava gelado quando chegamos.",
				    palavra = new String("frio");
		
		// Cria e inicializa as referências com os objetos das classes empacotadoras de tipo primitivo Integer e Double.
		Integer integer = Integer.valueOf(Integer.MAX_VALUE);
		final Double PI = Math.PI;
		
		// Cria e inicializa uma referência para um objeto da classe Character.
		Character characterA = Character.valueOf('A'); 
				
		System.out.println("\n- Tipos por Referência");
		System.out.printf("\n\tfrase: %s\n\tpalavra: %s\n\tpi: %1.15f\n\tInteger.MAX_VALUE: %,d", frase, palavra, PI,
									     integer);
		
		System.out.printf("\n\tCaractere A: %c", characterA.charValue());
		
		/* Um caractere UNICODE é representado no código usando a sintaxe '\\uNNNN', onde NNNN é o código UNICODE
		 * do caractere.  */
		System.out.printf("\n\t©: %s", Character.getName('\u00A9'));
		System.out.printf("\n\t%c: %s", '\u00A9', Character.getName('\u00A9'));
		
		System.out.printf("\n\t%s %s letra", characterA.toString(), Character.isLetter(characterA.charValue()) ? "é" : "não é");
		System.out.printf("\n\t%s(#) %s letra", Character.getName('\u0023'), Character.isLetter('\u0023') ? "é" : "não é");
	}
} // class TiposDeDados 
