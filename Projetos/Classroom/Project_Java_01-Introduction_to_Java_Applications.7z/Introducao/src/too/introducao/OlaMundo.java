package too.introducao;

/*
 * Regras para criação de identificadores:
 *  
 *  OlaMundo        -> classe ou interface ou enumeração 
 *  olaMundo         -> variável
 *  olaMundo()	     -> método
 *  OLA_MUNDO   -> constante
 */
public class OlaMundo {

	/**
	 * Inicia o programa Java.
	 *  
	 * @param args recebe os argumentos da linha de comando do sistema operacional.
	 */
	public static void main(String[] args) {
		olaMundo();
	}

	public static void olaMundo() {
		System.out.println("\tBem-vindo a programação em Java.");
		System.out.print("\tSaudações Atléticanas");
		System.out.printf("\n\tTchau!\n");
	}
}