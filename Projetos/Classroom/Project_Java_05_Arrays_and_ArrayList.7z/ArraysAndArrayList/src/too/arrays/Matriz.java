package too.arrays;

public class Matriz {

	public static void main(String[] args) {
		matriz();
	}

	/**
	 * Apresenta o array bidimensional (matriz).
	 */
	public static void matriz() {
		// Define uma referência para uma matriz do tipo int.
		int matriz3x3[][]; 
		
		// Cria uma matriz de números inteiros.
		matriz3x3 =  new int[3][3];
		
		/* Cria uma matriz escada onde cada linha tem um tamanho (número de colunas) diferente.
		 * Cria uma matriz com 5 linhas e um número indefinido de colunas em cada linha.
		 */
		int[][] matrizEscada = new int[5][];
		
		// Cria o conteúdo de cada linha da matriz, ou seja, define a quantidade de colunas em cada linha da matriz.
		for (int linha = 0; linha < matrizEscada.length; linha++)
			matrizEscada[linha] = new int[linha + 1]; // Cria o número de colunas de cada linha da matriz.

		exibirMatriz(matriz3x3, "Matriz 3x3\n");
		exibirMatriz(matrizEscada, "Matriz Escada\n");
		
		inicializarMatriz(matriz3x3, 1, 2);
		inicializarMatriz(matrizEscada, -2, -2);
		
		exibirMatriz(matriz3x3, "Matriz 3x3\n");
		exibirMatriz(matrizEscada, "Matriz Escada\n");
	} // void matriz()

	/**
	 * Exibe no console uma mensagem e os números da matriz no formato tabular.
	 */
	public static void exibirMatriz(int[][] matriz, String mensagem) {
		System.out.print(mensagem);
		
		for (int[] vetor : matriz)  { // Percorre as linhas da matriz. 
			for (int numero : vetor) // Percorre as colunas da matriz.
				System.out.printf("%,d\t", numero);
			
			// Avança para a próxima linha no console.
			System.out.println();
		}
		System.out.println();
	}
	
	/**
	 * Inicializa uma matriz de números inteiros sequenciais começando com inicio e incrementando ou decrementando 
	 * com passo.
	 */
	public static void inicializarMatriz(int[][] matriz, int inicio, int passo) {
		// Percorre as linhas da matriz.
		for (int numero = inicio, linha = 0; linha < matriz.length; linha++)
			// Percorre as colunas da matriz.
			for (int coluna = 0; coluna < matriz[linha].length; coluna++, numero += passo)
				matriz[linha][coluna] = numero;
	}
} // class Matriz
