package too.arrays.gui;

import static too.arrays.gui.EntradaSaida.*;

import java.util.Arrays;
import java.util.Scanner;

public class Vetor {
	private static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		vetor();
	}

	/**
	 * Apresenta o array unidimensional (vetor).
	 */
	public static void vetor() {
		int numerosPares[], // Define uma referência para um vetor do tipo int.
		      numerosImpares[] = { 17, 9, 23, 1, 45, 7, 5, 81, 15 }, // Define e inicializa um vetor do tipo int.
		      dez = 10; // Define uma variável do tipo int.
		
		char vogais[] = {'a', 'e', 'i', 'o', 'u' };
		
		// Cria um vetor de números inteiros.
		numerosPares = new int[dez];
		int[] numerosInteiros = new int[dez * 2]; 
		long[] numerosInteirosGrandes = new long[dez];

		// Os vetores em Java são inicializados durante a criação.
		System.out.println(Arrays.toString(numerosPares));
		System.out.println(Arrays.toString(numerosInteiros));
		System.out.println(Arrays.toString(numerosInteirosGrandes));
		
		inicializarVetor(numerosPares, 0, 2);
		inicializarVetor(numerosInteiros, -1, -1);
		inicializarVetor(numerosInteirosGrandes, Integer.MAX_VALUE, 1);
		
		// Solução 1: usa o método formatar(String...) da classe EntradaSaida.
		StringBuilder stringBuilder = formatar("Números pares: ", Arrays.toString(numerosPares), NOVA_LINHA, 
																	         "Números ímpares: ", Arrays.toString(numerosImpares), NOVA_LINHA,
																	         "Números: ", Arrays.toString(numerosInteiros));
		 
		msgInfo(stringBuilder.toString(), "Vetor usando Arrays.toString");

		pesquisarNumero(numerosImpares);
		
		// Classifica o vetor de números inteiros.
		Arrays.sort(numerosImpares);
		
		pesquisarNumero(numerosImpares);
			
		// Solução 2: usa o método formatar(int...) da classe EntradaSaida.
		stringBuilder = formatar("Números pares: ", formatar(numerosPares).toString(), NOVA_LINHA, 
			     					                 "Números ímpares: ", formatar(numerosImpares).toString(), NOVA_LINHA,
			     									 "Números inteiros (int): ", formatar(numerosInteiros).toString(), NOVA_LINHA,
			     									 "Números inteiros (long): ", formatar(numerosInteirosGrandes).toString());
		
		// Copia os caracteres do vetor vogais para o vetor letras criando um novo vetor de 26 caracteres.
		char[] letras = Arrays.copyOf(vogais, 26);
				
		System.out.printf("\nLetras: %s", Arrays.toString(letras));				

		/* Preenche o vetor letras com o caractere ponto (.). O preenchimento é feito da posição 5 até a última 
		 * posição do vetor.
		 */
		Arrays.fill(letras, 5, letras.length, '.');
		
		System.out.printf("\nLetras: %s\n", Arrays.toString(letras));

		msgInfo(stringBuilder.toString(), "Vetor usando os métodos EntradaSaida.formatar");
		
		scanner.close();
		System.exit(0);
	} // vetor()

	/**
	 * Realiza um teste de pesquisa em um vetor de números inteiros.
	 */
	private static void pesquisarNumero(int[] vetor) {
		int numeroImpar = 0;
		
		do { System.out.printf("\nNúmero ímpar ou zero para sair: ");
		    	numeroImpar = scanner.nextInt();
				
				// Pesquisa pelo número no vetor.
				int posicao = Arrays.binarySearch(vetor, numeroImpar);
				if (posicao >= 0)
					System.out.printf("\nNúmero encontrado na posição %d do vetor.", posicao);
				else
					System.err.println("\nNúmero não encontrado.");
				
		} while (numeroImpar != 0);
	}
	
	/**
	 * Inicializa um vetor de números inteiros sequenciais começando com inicio e incrementando ou decrementando 
	 * com passo.
	 */
	public static void inicializarVetor(int[] vetor, int inicio, int passo) {
		// Percorre o vetor da primeira até a última posição para iniciá-lo.
		for (int numero = inicio, indice = 0; indice < vetor.length; indice++, numero += passo)
			vetor[indice] = numero;
	}
	
	/**
	 * Inicializa um vetor de números inteiros sequenciais começando com inicio e incrementando ou decrementando 
	 * com passo.
	 */
	public static void inicializarVetor(long[] vetor, long inicio, long passo) {
		var numero = inicio;
		
		// Percorre o vetor da primeira até a última posição para iniciá-lo.
		for (int indice = 0; indice < vetor.length; indice++, numero += passo)
			vetor[indice] = numero;
	}
} // class Vetor