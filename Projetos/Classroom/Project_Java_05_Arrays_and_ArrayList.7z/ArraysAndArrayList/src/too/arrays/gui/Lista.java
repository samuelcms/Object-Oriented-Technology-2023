package too.arrays.gui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static too.arrays.gui.EntradaSaida.*;

public class Lista {

	public static void main(String[] args) {
		lista();
	}

	public static void lista() {
		// Cria lista para armazenar objetos Integer e String.
		List<Integer> numerosList = new ArrayList<>();
		List<String> stringList = new ArrayList<String>(); 
		
		inicializarLista(numerosList, 2, 9, 15, 4, 33, 7, 47, 10, 22);
		inicializarLista(stringList, "água", "terra", "fogo", "ar");

		/* Chama o método toString, versão sobrescrita (override) da classe AbstractCollection, para obter os elementos 
		 * da lista separados por vírgula e entre colchetes. 
		 */
		StringBuilder stringBuilder = formatar("Números inteiros: ", numerosList.toString(), NOVA_LINHA,
                															 "Palavras: ", stringList.toString()); 
		// Classifica as listas.
		Collections.sort(numerosList);
		Collections.sort(stringList);
		
		stringBuilder.append(formatar(LINHA_VAZIA, "Listas Classificadas", LINHA_VAZIA, 
																"Números inteiros: ", numerosList.toString(), NOVA_LINHA,  
																"Palavras: ", stringList.toString()));

		
		// Pesquisa um elemento na lista.
		if (stringList.contains("TERRA".toLowerCase()))
			System.out.println("A palavra terra pertence a lista de strings.");
		else
			System.out.println("A palavra terra não pertence a lista de strings.");
		
		// Obtém uma sublista da lista de números.
		stringBuilder.append(formatar(LINHA_VAZIA, "Sublista de números inteiros: ", 
																 numerosList.subList(0, numerosList.size() / 2).toString()));
		
		// Obtém um vetor com os elementos da lista.
		stringBuilder.append(formatar(LINHA_VAZIA, "Vetor de strings: ", Arrays.toString(stringList.toArray())));
		
		// Pesquisa a posição de um elemento na lista.
		int posicao = numerosList.indexOf(15);
		System.out.printf("O número 15 %sestá na posição %d da lista de números.",  posicao >= 0? "" : "não ", posicao);
		
		// Apaga todos os elementos da lista.
		numerosList.clear();
		stringList.clear();
		
		System.out.printf("\n\nLista vazia de números inteiros: %s - Tamanho: %d", numerosList.toString(), numerosList.size());
		System.out.printf("\nLista vazia de strings: %s - Tamanho: %d", stringList.toString(), stringList.size());
		
		// Exibe o resultado.
		msgInfo(stringBuilder.toString(), "List e ArrayList");
		
		// Finaliza o programa.
		System.exit(0);
	} // lista()

	/**
	 * Preenche a lista com os números fornecidos.
	 */
	public static void inicializarLista(List<Integer> list, int... numeros) {
		for (int numero : numeros)
			list.add(numero); // Usa o recurso autoboxing. 
	}
	
	/**
	 * Preenche a lista com as strings fornecidas.
	 */
	public static void inicializarLista(List<String> list, String... strings) {
		for (var string : strings)
			list.add(string);  
	}

} // class Lista