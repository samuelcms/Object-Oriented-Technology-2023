package too.classeeobjeto1;

public class Produto {
	// Variáveis de instância.
	private String nome;
	private int quantidade;
	private float preco;
	
	/**
	 * Construtor default ou padrão.
	 */
	public Produto() {
		nome = "";
	}

	/**
	 * Construtor sobrecarregado.
	 */
	public Produto(String nome, int quantidade, float preco) {
		this.nome = nome;
		this.quantidade = quantidade;
		this.preco = preco;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		this.quantidade = quantidade;
	}

	public float getPreco() {
		return preco;
	}

	public void setPreco(float preco) {
		this.preco = preco;
	}

	@Override
	public String toString() {
		return String.format("Produto: %s, Quantidade: %,d, R$ %,1.2f", nome, quantidade, preco);
	}
} // class Produto