package too.classeeobjeto1.gui;

import static too.classeeobjeto1.gui.EntradaSaida.*;

public class AutoboxingUnboxing {

	public static void main(String[] args) {
		autoboxingUnboxing();
	}

	public static void autoboxingUnboxing() {
			/* Autoboxing: cria um objeto de alguma classe empacotadora de tipo primitivo e armazena o valor desse tipo 
			 *                         no objeto. */
			Integer integer = 10;
			Boolean boolean1 = true;
			final Double PI = Math.PI;
			
			/* Auto-unboxing: acessa um objeto de alguma classe empacotadora de tipo primitivo para recuperar o valor
			 *                               desse tipo armazenado no objeto. */
			int dez = integer;
			boolean verdadeiro = boolean1;
			double pi = PI;
			
			// Os três primeiros códigos de formatação abaixo usam o recurso auto-unboxing.
			msgInfo(String.format("Autoboxing\n\n%d\n%b\n%1.15f\n\nAuto-unboxing\n\n%d\n%b\n%1.15f", integer, 
					                                 boolean1, PI, dez, verdadeiro, pi), "Autoboxing e auto-unboxing");
			
			Integer matricula = lerNumeroInteiro("Matrícula:", "Cadastro de Discente");
			if (matricula != null)
				msgInfo(String.format("Matrícula: %d", matricula),"Cadastro de Discente"); // auto-unboxing
			else
				msgAlerta("O usuário cancelou a operação.", "Cadastro de Discente");
			
			System.exit(0);
	} // autoboxingUnboxing()
} // class AutoboxingUnboxing