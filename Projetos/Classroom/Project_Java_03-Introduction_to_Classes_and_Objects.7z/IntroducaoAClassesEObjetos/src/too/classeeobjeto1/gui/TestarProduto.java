package too.classeeobjeto1.gui;

import too.classeeobjeto1.Produto;
 import static too.classeeobjeto1.gui.EntradaSaida.*;

public class TestarProduto {

	public static void main(String[] args) {
		testarProduto();
	}

	public static void testarProduto() {
		Produto carro = new Produto(),
				        pc =  new Produto("Dell PC Gamer", 1, 8999);
		String resultado = carro + "\n" + pc.toString();
		
		/*
		 * carro.nome = "La Ferrari"; // ERRO: porque a variável de instância nome possui acesso privado.
		 */
		
		// Define os atributos do objeto enviando uma mensagem para ele.
		carro.setNome("La Ferrari");
		carro.setQuantidade(1);
		carro.setPreco(8000000);
		
		/* Solução 1: usa concatenação de string. 
		 * 					resultado += "\n\n" + carro + "\n\n" + obterProduto(pc);
		 * 
		 * Solução 2: elimina as concatenações de string.
		 */
		resultado += String.format("\n\n%s\n\n%s", carro, obterProduto(pc));

		// Exibe o resultado em uma caixa de diálogo.
		msgInfo(resultado, "Teste da Classe Produto");
		
		System.exit(0);
	} // testarProduto()
	
	/**
	 * Obtém uma representação string com os dados do produto.
	 */
	public static String obterProduto(Produto produto) {
		return String.format("Nome: %s\nQuantidade: %,d\nPreço: R$ %,1.2f", produto.getNome(), 
				                               produto.getQuantidade(), produto.getPreco());
	}
} // class TestarProduto