package mos.pt;

import java.util.ArrayList;
import java.util.List;

public class Exercicio {
	// Representa os detalhes de todos os exercícios.
	private String nome, data, tempo, duracao;
	private float distancia;
	private int caloriasPerdidas, passos;
	
	// Representa os detalhes específicos para alguns exercícios.
	private VelocidadeRitmoElevacao velocidadeRitmoElevacao;
	private List<RitmoPorKm > ritmoPorKmList;
	
	public Exercicio() {
		nome = data = tempo = duracao = "";
	}

	public Exercicio(String nome, String data, String tempo, String duracao, float distancia, int caloriasPerdidas, int passos) {
		this.nome = nome;
		this.data = data;
		this.tempo = tempo;
		this.duracao = duracao;
		this.distancia = distancia;
		this.caloriasPerdidas = caloriasPerdidas;
		this.passos = passos;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getTempo() {
		return tempo;
	}

	public void setTempo(String tempo) {
		this.tempo = tempo;
	}

	public String getDuracao() {
		return duracao;
	}

	public void setDuracao(String duracao) {
		this.duracao = duracao;
	}

	public float getDistancia() {
		return distancia;
	}

	public void setDistancia(float distancia) {
		this.distancia = distancia;
	}

	public float getCaloriasPerdidas() {
		return caloriasPerdidas;
	}

	public void setCaloriasPerdidas(int caloriasPerdidas) {
		this.caloriasPerdidas = caloriasPerdidas;
	}

	public int getPassos() {
		return passos;
	}

	public void setPassos(int passos) {
		this.passos = passos;
	}

	public VelocidadeRitmoElevacao getVelocidadeRitmoElevacao() {
		return velocidadeRitmoElevacao;
	}

	public void setVelocidadeRitmoElevacao(VelocidadeRitmoElevacao velocidadeRitmoElevacao) {
		this.velocidadeRitmoElevacao = velocidadeRitmoElevacao;
	}
	
	/**
	 * Adiciona um ritmo por km da pessoa no exercício.
	 */
	public void adicionarRitmoPorKm(RitmoPorKm ritmoPorKm) {
		// Só cria a lista para armazenar os ritmos se o exercício possui ritmos por km a serem adicionados no exercício.
		if (ritmoPorKmList == null)
			ritmoPorKmList = new ArrayList<>();
		
		ritmoPorKmList.add(ritmoPorKm);
	}

	/**
	 * Obtém a relação de todos os ritmos por km do exercício. Se o exercício não possui nenhum ritmo retorna null. 
	 */
	public RitmoPorKm[] obterRitmoPorKm() {
		return ritmoPorKmList != null ?  ritmoPorKmList.toArray(new RitmoPorKm[ritmoPorKmList.size()]) : null;
	}


	@Override
	public String toString() {   
		StringBuilder ritmos = new StringBuilder();
		
		// Obtém os ritmos se o exercício possui ritmos por km.
		if (ritmoPorKmList != null) {
			ritmos.append("\n\n------ Ritmo ------\n");
			
			for (RitmoPorKm ritmoPorKm : ritmoPorKmList) {
				ritmos.append(ritmoPorKm);
				ritmos.append("\n");
			}
		}
		return String.format("Exercício: %s | %s | %s | %s | %1.2f Km | %d Kcal | %,d passos%s%s", nome, data, tempo, duracao, distancia, caloriasPerdidas, passos, 
				                                 velocidadeRitmoElevacao != null ? velocidadeRitmoElevacao : "", ritmos);
	}
} // class Exercicio 
