package mos.pt.test;

import mos.pt.Exercicio;
import mos.pt.Pessoa;
import mos.pt.RitmoPorKm;
import mos.pt.VelocidadeRitmoElevacao;

public class PersonalTrainingTest {

	public static void main(String[] args) {
		personalTrainingTest();
	}

	private static void personalTrainingTest() {
		Pessoa bruno = new Pessoa("Bruno Silva", "22/04/1980", "masculino", 1.7f, 76);
		Exercicio basquete = new Exercicio("basquete", "20/05/2022", "15:00 - 15:30", "30m0s", 4.54f, 580, 4152),
		                  caminhada = new Exercicio("caminhada", "20/05/2022", "10:30 - 11:42", "60m12s", 6.75f, 375, 8298);
		VelocidadeRitmoElevacao velocidadeRitmoElevacao = new VelocidadeRitmoElevacao(6.5f, 9, "09'08\"", "06'40\"", 1044, 1154);

		bruno.adicionarExercicio(basquete);
		bruno.adicionarExercicio(caminhada);
		
		caminhada.setVelocidadeRitmoElevacao(velocidadeRitmoElevacao);
		caminhada.adicionarRitmoPorKm(new RitmoPorKm(1, "09'15\""));
		caminhada.adicionarRitmoPorKm(new RitmoPorKm(2, "09'00\""));
		caminhada.adicionarRitmoPorKm(new RitmoPorKm(3, "08'54\""));
		caminhada.adicionarRitmoPorKm(new RitmoPorKm(4, "08'56\""));
		caminhada.adicionarRitmoPorKm(new RitmoPorKm(5, "09'06\""));
		caminhada.adicionarRitmoPorKm(new RitmoPorKm(6, "09'09\""));
		caminhada.adicionarRitmoPorKm(new RitmoPorKm(6.75f, "09'45\""));
		
		System.out.println(bruno);
		System.out.println();
		System.out.println(caminhada);
		System.out.println(basquete);
	}
} // class PersonalTrainingTest