package mos.pt;

import java.util.ArrayList;
import java.util.List;

public class ExercicioList {
	private List<Exercicio> exercicioList;

	public ExercicioList() {
		exercicioList = new ArrayList<>();
	}

	/**
	 * ATENÇÃO: Este método get é desnecessário para esta solução, portanto não deve ser incluído na classe ExercicioList.
	 *                      Ele foi colocado nessa classe apenas para se mostrar os risco do seu uso fora da classe. 
	 *                      Portanto, leia os comentários de ATENÇÃO e CUIDADO na classe TestarExercicioList.
	 */
	public List<Exercicio> getExercicioList() {
		return exercicioList;
	}

	/**
	 * Adiciona um exercício na lista.
	 */
	public void adicionar(Exercicio exercicio) {
		exercicioList.add(exercicio);
	}
	
	/**
	 * Obtém um exercício da lista. Se índice for inválido retorna null.
	 */
	public Exercicio obter(int indice) {
		return (indice >= 0 && indice < exercicioList.size()) ? exercicioList.get(indice) : null;
	}
	
	/**
	 * Obtém a relação de todos os exercícios da lista.
	 */
	public Exercicio[] obter() {
		//  O vetor obtido com o método toArray abaixo é criado antes de invocá-lo com o mesmo tamanho da lista, assim os elementos da lista são copiados para esse novo vetor.
		return exercicioList.toArray(new Exercicio[exercicioList.size()]);
	}
	
	/**
	 * Obtém o número de exercícios da lista.
	 */
	public int numeroExercicios() {
		return exercicioList.size();
	}
} // class ExercicioList