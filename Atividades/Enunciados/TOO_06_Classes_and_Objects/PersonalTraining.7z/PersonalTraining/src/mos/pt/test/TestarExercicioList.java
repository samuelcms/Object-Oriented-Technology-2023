package mos.pt.test;

import java.util.List;

import mos.pt.Exercicio;
import mos.pt.ExercicioList;

public class TestarExercicioList {

	public static void main(String[] args) {
		testarExercicioList();
	}

	/**
	 * ATENÇÃO: Este método mostra o risco de se incluir um método como get que retorna a referência da lista criada internamente na classe ExercicioList.
	 */
	private static void testarExercicioList() {
		Exercicio basquete = new Exercicio("basquete", "20/05/2022", "15:00 - 15:30", "30m0s", 4.54f, 580, 4152),
				          caminhada = new Exercicio("caminhada", "20/05/2022", "10:30 - 11:42", "60m12s", 6.75f, 375, 8298);
		ExercicioList exercicioList = new ExercicioList();
		
		exercicioList.adicionar(basquete);
		exercicioList.adicionar(caminhada);
		
		List<Exercicio> list = exercicioList.getExercicioList();
		
		exibirLista(list);
		
		/* CUIDADO: Ao alterar um elemento ou apagar todos os elementos da lista referenciada por list apaga-se também todos os objetos da lista criada internamente na classe ExercicioList.
		 *                       Isso mostra o risco que pode ser incluído em uma classe ao criar métodos simples como set e get usando a facilidade de gerá-los rapidamente na IDE Eclipse.
		 *                       Pode-se quebrar o encapsulamento (ocultamento de informações) ao compartilhar a referência de um objeto interno permitindo que ela seja alterado diretamente.
		 */
		list.set(0, caminhada); // altera um elemento da lista 
		
		exibirLista(exercicioList.getExercicioList());
		
		list.clear(); // apaga todos os elementos da lista 
		
		exibirLista(exercicioList.getExercicioList());
	}
	
	private static <E> void exibirLista(List<E> list) {
		System.out.printf("Número de elementos: %d\n", list.size());
		
		for (E elemento : list)
			System.out.println(elemento);
	}
} // class TestarExercicioList
