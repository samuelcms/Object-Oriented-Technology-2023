package mos.pt;

public class Pessoa {
	private String nome, sexo, dataNascimento;
	private float altura, peso;
	
	// Lista de exercícios da pessoa.
	private final ExercicioList exercicioList;
	
	public Pessoa() {
		nome = sexo = dataNascimento = "";
		exercicioList = new ExercicioList();
	}

	public Pessoa(String nome, String dataNascimento, String sexo, float altura, float peso) {
		this();
		this.nome = nome;
		this.dataNascimento = dataNascimento;
		this.sexo = sexo;
		this.altura = altura;
		this.peso = peso;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		this.sexo = sexo;
	}

	public float getAltura() {
		return altura;
	}

	public void setAltura(float altura) {
		this.altura = altura;
	}

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}

	/**
	 * Adiciona um exercício da pessoa.
	 */
	public void adicionarExercicio(Exercicio exercicio) {
		exercicioList.adicionar(exercicio);
	}

	/**
	 * Obtém um exercício da pessoa. Se índice for inválido retorna null.
	 */
	public Exercicio obterExercicio(int indice) {
		return exercicioList.obter(indice);
	}
	
	/**
	 * Obtém a relação de todos os exercícios da pessoa.
	 */
	public Exercicio[] obterExercicio() {
		return exercicioList.obter();
	}
	
	@Override
	public String toString() {  
		return String.format("%s: %s | %1.2f m | %1.1f Kg | %s", nome, sexo , altura, peso, dataNascimento);
	}
} // class Pessoa
