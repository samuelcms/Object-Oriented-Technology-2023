package mos.pt;

public class RitmoPorKm {
	private float quilometro;
	private String tempo;
	
	public RitmoPorKm() {
		tempo = "";
	}

	public RitmoPorKm(float quilometro, String tempo) {
		this.quilometro = quilometro;
		this.tempo = tempo;
	}

	public float getQuilometro() {
		return quilometro;
	}

	public void setQuilometro(float quilometro) {
		this.quilometro = quilometro;
	}

	public String getTempo() {
		return tempo;
	}

	public void setTempo(String tempo) {
		this.tempo = tempo;
	}

	@Override
	public String toString() {
		return String.format("%1.2f Km: %s", quilometro, tempo);
	}
} // class Ritmo
