package scms.textfile.classes;

import scms.textfile.dao.TextFileDAO;

public  class Item extends TextFileDAO 
{
	public String getNome()
	{
		return "";
	}
}
