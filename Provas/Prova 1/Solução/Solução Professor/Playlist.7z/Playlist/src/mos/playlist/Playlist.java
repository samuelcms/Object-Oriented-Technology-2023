package mos.playlist;

import static javax.swing.SwingConstants.CENTER;
import static javax.swing.SwingConstants.LEFT;
import static mos.io.InputOutput.*;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JScrollPane;

import mos.reader.Line;
import mos.reader.Reader;

public class Playlist {
	private String fileName;
	private List<Musica> musicaList;
	private List<Line>  lineList;
	
	/**
	 * Importa as músicas do arquivo csv e insere essas músicas na lista de músicas.
	 */
	public Playlist(String fileName) {
		this.fileName = fileName;
		musicaList = new ArrayList<>();
		
		// Importa as músicas armazenadas no arquivo csv.
		lineList = toImport(fileName);
		
		// Insere as músicas importadas na lista de músicas.
		if (lineList != null)
			for (Line line : lineList)
				insert(new Musica(line.getData(0), line.getData(1), line.getData(4), line.getData(2), Short.parseShort(line.getData(3)), Short.parseShort(line.getData(5))));
	}
	
	public String getFileName() {
		return fileName;
	}

	/**
	 * Exibe a playlist e um relatório com as músicas classificadas em ordem ascendente pelo seu tempo em segundos.
	 */
	public void playlist() {
		if (lineList != null) {
			final short ONE_MINUTE = 60;
			
			// Define os nomes das colunas da tabela.
			String columnNames[] = {"Álbum", "Nº", "Título", "Tempo (s)"};

			// Define a largura e o alinhamento das colunas da tabela.
			int columnWidths[] = {140, 20, 200, 30}, columnAlignments[] = {LEFT, CENTER, LEFT, CENTER};

			// Obtém uma matriz com todas as músicas da playlist e exibe a playlist em uma tabela.
			showTable("Playlist Legião Urbana", toArray(), columnNames, columnWidths, columnAlignments, 560, 300);
			
			// Obtém o tempo total (em segundos) das músicas da playlist.
			float totalTime = totalTime();	
			
			// Cria o relatório com as músicas classificadas em ordem ascendente pelo seu tempo em segundos.
			writeTextArea(String.format("Playlist classificada pelo tempo da música\nNúmero de Músicas = %,d\nTempo total = %,1.0f segundos ou %1.2f minutos\n\n", size(), totalTime, totalTime / ONE_MINUTE));
			
			for (String musica : toList()) {
				writeTextArea(musica);
				writeTextArea(NEW_LINE);
			}
			// Exibe o relatório.
			showInfo(new JScrollPane(getTextArea()), "Playlist Legião Urbana");
		}
		System.exit(0);
	} 
	
	
	/** 
	 * Obtém uma matriz com todas as músicas da playlist. 
	 * Os dados a serem armazenados nessa matriz são o nome do álbum, o número da música no álbum, o título e o tempo da música em segundos.
	*/
	public Object[][] toArray() {
		Object lines[][] = new Object[ (lineList != null) ? size() : 1 ][4];

		for (int indexLine = 0; indexLine < lineList.size(); indexLine++) {
				Line line = lineList.get(indexLine);
				lines[indexLine][0] = line.getData(2);
				lines[indexLine][1] = line.getData(3);
				lines[indexLine][2] = line.getData(1);
				lines[indexLine][3] = line.getData(5);
		}
		return lines;
	} 
	
	/** 
	 *  Importa as músicas armazenadas no arquivo csv.
	 *  
	 *  @param fileName nome do arquivo csv que possui as músicas da playlist.
	 *  
	 *  @return uma lista com as linhas de dados do arquivo csv ou null se ocorrer um erro de leitura.
	*/
	public List<Line> toImport(String fileName) {
		return Reader.read(fileName, Reader.SEMICOLON);
	}
	
	/**
	 * Insere uma música na playlist.
	*/
	public Playlist insert(Musica musica) {
		if (musica != null)
			musicaList.add(musica);
		return this;
	}
	
	/**
	 * Obtém uma lista com todas as músicas da playlist ordenadas ascendentemente pelo tempo da música em segundos. Cada string da lista possui o formato abaixo.
	 * 
	 * 						<tempo s> - <titulo>
	 * 						Exemplo: 547 s - Faroeste Cabloco
	*/
	public List<String> toList() {
		List<String> tempoMusicaList = new ArrayList<>();
		
		// Insere o tempo e o título da música na lista.
		for (Musica musica : musicaList)
			tempoMusicaList.add(String.format("%03d s - %s", musica.getTempo(), musica.getTitulo()));
		
		// Classifica a lista em ordem ascendente.
		Collections.sort(tempoMusicaList);
		
		return tempoMusicaList;
	}
	
	/**
	 * Calcula o tempo total em segundos de todas as músicas da playlist.
	*/
	public int totalTime() {
		int totalTime = 0;
		
		for (Musica musica : musicaList)
			totalTime += musica.getTempo();
		
		return totalTime;
	}
	
	/**
	* Obtém o tamanho (número de músicas) da playlist.
	*/
	public int size() {
		return musicaList.size();
	}

	/**
	 * Inicia o programa playlist.
	 */
	public static void main(String[] args) {
		new Playlist("playlist.csv").playlist();
	}
} // class Playlist 
