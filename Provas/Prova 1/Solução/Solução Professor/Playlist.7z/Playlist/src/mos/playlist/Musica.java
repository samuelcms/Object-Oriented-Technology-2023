package mos.playlist;

/**
 * @author Márlon
 *
 */
public class Musica {
	private String artista, titulo, genero, album; 
	private short numero, tempo;
	
	public Musica() {
		artista = titulo = genero = album = "";
	}

	public Musica(String artista, String titulo, String genero, String album, short numero, short tempo) {
		this.artista = artista;
		this.titulo = titulo;
		this.genero = genero;
		this.album = album;
		this.numero = numero;
		this.tempo = tempo;
	}

	public String getArtista() {
		return artista;
	}

	public void setArtista(String artista) {
		this.artista = artista;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getAlbum() {
		return album;
	}

	public void setAlbum(String album) {
		this.album = album;
	}

	public short getNumero() {
		return numero;
	}

	public void setNumero(short numero) {
		this.numero = numero;
	}

	public short getTempo() {
		return tempo;
	}

	public void setTempo(short tempo) {
		this.tempo = tempo;
	}

	@Override
	public String toString() {
		return String.format("%02d. %s - %s (%d s)", numero, artista, titulo, tempo);
	}
} // class Musica
